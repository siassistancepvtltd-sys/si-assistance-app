import React from 'react';
import { PhoneCall, MessageCircle, Truck } from 'lucide-react';
import { COMPANY_INFO } from '../data/mockData';
import { ScreenType } from '../types';

interface ShowcaseGalleryProps {
  onSelectScreenToSimulate: (screen: ScreenType) => void;
}

export const ShowcaseGallery: React.FC<ShowcaseGalleryProps> = ({
  onSelectScreenToSimulate,
}) => {
  const showcaseScreens: {
    id: ScreenType;
    label: string;
    description: string;
  }[] = [
    { id: 'splash', label: 'Splash Screen', description: 'Brand hero with recovery truck & 3 pillars' },
    { id: 'home', label: 'Home Screen', description: 'Dual emergency CTAs & 6 service grid' },
    { id: 'services_list', label: 'Services List', description: 'Detailed catalog with thumbnails' },
    { id: 'service_details', label: 'Service Details', description: 'Vehicle selector chips & feature checklist' },
    { id: 'booking_form', label: 'Booking Form', description: 'Name, Mobile, Vehicle No, Location & Issue' },
    { id: 'select_location', label: 'Location Selection', description: 'Interactive GPS pin & Kanpur map' },
    { id: 'booking_confirmation', label: 'Booking Confirmation', description: 'Unique Booking ID & WhatsApp ping' },
    { id: 'my_bookings', label: 'My Bookings', description: 'Current & History cards with Track Status' },
    { id: 'booking_status', label: 'Booking Status Tracking', description: '5-step live tracker & Call Driver' },
    { id: 'contact_us', label: 'Contact Us', description: 'Primary phone, WhatsApp & Kanpur HQ' },
    { id: 'about_us', label: 'About Us', description: 'Company mission & 24x7 guarantee' },
    { id: 'more', label: 'More / Settings', description: 'FAQs, Terms, Privacy & Rate App' },
  ];

  return (
    <div className="bg-[#020B1C] text-white min-h-screen p-4 md:p-8">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto mb-8 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-sky-400 text-xs font-bold mb-3 border border-blue-500/30">
          <Truck className="w-3.5 h-3.5" />
          <span>Complete 12-Screen UI Showcase</span>
        </div>
        <h1 className="text-2xl md:text-4xl font-black uppercase tracking-tight text-white">
          {COMPANY_INFO.name}
        </h1>
        <p className="text-xs md:text-sm font-bold tracking-widest text-sky-400 uppercase mt-1">
          {COMPANY_INFO.subheading}
        </p>
        <p className="text-sm md:text-base text-amber-400 font-semibold mt-2 italic font-['Noto_Sans_Devanagari',sans-serif]">
          "{COMPANY_INFO.taglineHindi}"
        </p>
        <p className="text-xs text-slate-400 mt-2 max-w-xl mx-auto">
          Click any screen below to enter the interactive phone simulator, submit bookings,
          track live recovery units, or test emergency calling features.
        </p>
      </div>

      {/* Grid of 12 Showcase Screens */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {showcaseScreens.map((item, index) => (
          <div
            key={item.id}
            onClick={() => onSelectScreenToSimulate(item.id)}
            className="group bg-slate-900/90 rounded-3xl p-3 border border-slate-800 hover:border-sky-500/60 shadow-xl cursor-pointer transition-all hover:-translate-y-1 hover:shadow-sky-500/10 flex flex-col items-center"
          >
            {/* Phone Frame Mockup container */}
            <div className="w-full aspect-[9/18.5] bg-slate-950 rounded-2xl overflow-hidden border-2 border-slate-700/60 relative group-hover:border-sky-400 transition-colors">
              {/* Screen Preview Graphic / Badge */}
              <div className="absolute inset-0 flex flex-col justify-between p-3 bg-gradient-to-b from-[#003882] to-[#001738] text-white">
                {/* Status Bar */}
                <div className="flex justify-between items-center text-[10px] text-white/80 font-bold px-1">
                  <span>9:41</span>
                  <span>●●● 4G</span>
                </div>

                {/* Center Content Preview */}
                <div className="my-auto text-center p-2">
                  <div className="w-10 h-10 rounded-2xl bg-white/10 mx-auto flex items-center justify-center text-sky-400 mb-2 border border-white/20">
                    <Truck className="w-5 h-5" />
                  </div>
                  <h4 className="text-xs font-bold uppercase tracking-tight text-white">
                    {item.label}
                  </h4>
                  <p className="text-[10px] text-slate-300 mt-1 line-clamp-2">
                    {item.description}
                  </p>
                  <span className="mt-3 inline-block px-2.5 py-1 bg-[#0048A7] group-hover:bg-[#0062E0] text-[10px] font-bold rounded-lg text-white shadow-sm transition-colors">
                    Open Screen →
                  </span>
                </div>

                {/* Bottom Bar indicator */}
                <div className="w-16 h-1 bg-white/30 rounded-full mx-auto" />
              </div>
            </div>

            {/* Label Underneath */}
            <div className="mt-3 text-center">
              <span className="text-xs font-bold text-white group-hover:text-sky-400 transition-colors">
                {item.label}
              </span>
              <p className="text-[10px] text-slate-400 mt-0.5 font-mono">
                Screen {index + 1} of 12
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Showcase Bottom Strip matching user screenshot */}
      <div className="max-w-7xl mx-auto mt-12 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-[#0048A7] flex items-center justify-center p-2 shadow-lg border border-sky-400/30">
            <Truck className="w-8 h-8 text-sky-400" />
          </div>
          <div>
            <h3 className="text-xl font-black uppercase text-white tracking-tight">
              {COMPANY_INFO.name}
            </h3>
            <p className="text-xs font-bold text-sky-400 tracking-wider uppercase">
              {COMPANY_INFO.subheading}
            </p>
          </div>
        </div>

        <div className="px-4 py-2 bg-white/5 rounded-2xl border border-white/10">
          <p className="text-sm md:text-base font-bold text-amber-300 font-['Noto_Sans_Devanagari',sans-serif]">
            {COMPANY_INFO.taglineHindi}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <a
            href={`tel:${COMPANY_INFO.primaryPhoneRaw}`}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-red-500 text-white font-bold text-xs shadow-md active:scale-95 transition-transform"
          >
            <PhoneCall className="w-4 h-4" />
            <span>{COMPANY_INFO.primaryPhone}</span>
          </a>
          <a
            href={`https://wa.me/${COMPANY_INFO.whatsappPhoneRaw.replace('+', '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#00A859] text-white font-bold text-xs shadow-md active:scale-95 transition-transform"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{COMPANY_INFO.whatsappPhone}</span>
          </a>
        </div>
      </div>
    </div>
  );
};
