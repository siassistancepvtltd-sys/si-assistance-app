import React from 'react';
import {
  X,
  PhoneCall,
  MessageCircle,
  Truck,
  Wrench,
  Calendar,
  Info,
  HelpCircle,
  FileText,
  Shield,
  MapPin,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { COMPANY_INFO } from '../data/mockData';
import { ScreenType } from '../types';

interface DrawerMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (screen: ScreenType) => void;
}

export const DrawerMenu: React.FC<DrawerMenuProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer Content */}
      <div className="relative w-4/5 max-w-xs bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-200">
        {/* Header */}
        <div className="bg-[#0048A7] text-white p-5 pt-8">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center p-1.5">
                <Truck className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold tracking-tight">{COMPANY_INFO.name}</h2>
                <p className="text-[10px] text-blue-200 tracking-wider font-medium">
                  {COMPANY_INFO.subheading}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-xs text-amber-300 font-medium mt-3 italic">
            "{COMPANY_INFO.taglineHindi}"
          </p>
        </div>

        {/* Quick Emergency Actions */}
        <div className="p-4 grid grid-cols-2 gap-2 bg-slate-50 border-b border-slate-100">
          <a
            href={`tel:${COMPANY_INFO.primaryPhoneRaw}`}
            className="flex items-center justify-center gap-1.5 py-2.5 px-2 bg-gradient-to-r from-red-600 to-red-500 text-white rounded-xl text-xs font-bold shadow-sm active:scale-95 transition-transform"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Call 24x7</span>
          </a>
          <a
            href={`https://wa.me/${COMPANY_INFO.whatsappPhoneRaw.replace('+', '')}?text=Hi%20SI%20Assistance,%20I%20need%20roadside%20help`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 py-2.5 px-2 bg-[#00A859] text-white rounded-xl text-xs font-bold shadow-sm active:scale-95 transition-transform"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </a>
        </div>

        {/* Menu Items */}
        <div className="flex-1 overflow-y-auto py-2 px-3 space-y-1">
          <button
            onClick={() => {
              onNavigate('home');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-800 text-sm font-semibold transition-colors"
          >
            <div className="flex items-center gap-3">
              <Truck className="w-5 h-5 text-[#0048A7]" />
              <span>Home</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            onClick={() => {
              onNavigate('services_list');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-800 text-sm font-semibold transition-colors"
          >
            <div className="flex items-center gap-3">
              <Wrench className="w-5 h-5 text-[#0048A7]" />
              <span>Our Services</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            onClick={() => {
              onNavigate('booking_form');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-800 text-sm font-semibold transition-colors"
          >
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-[#0048A7]" />
              <span>Book Assistance</span>
            </div>
            <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-bold">
              Instant
            </span>
          </button>

          <button
            onClick={() => {
              onNavigate('my_bookings');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-800 text-sm font-semibold transition-colors"
          >
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-[#0048A7]" />
              <span>My Bookings</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            onClick={() => {
              onNavigate('about_us');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-800 text-sm font-semibold transition-colors"
          >
            <div className="flex items-center gap-3">
              <Info className="w-5 h-5 text-[#0048A7]" />
              <span>About Us</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            onClick={() => {
              onNavigate('contact_us');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-800 text-sm font-semibold transition-colors"
          >
            <div className="flex items-center gap-3">
              <PhoneCall className="w-5 h-5 text-[#0048A7]" />
              <span>Contact Us</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <div className="my-2 border-t border-slate-100" />

          <button
            onClick={() => {
              onNavigate('faqs');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-700 text-sm font-medium transition-colors"
          >
            <div className="flex items-center gap-3">
              <HelpCircle className="w-5 h-5 text-slate-500" />
              <span>FAQs</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            onClick={() => {
              onNavigate('terms');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-700 text-sm font-medium transition-colors"
          >
            <div className="flex items-center gap-3">
              <FileText className="w-5 h-5 text-slate-500" />
              <span>Terms & Conditions</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            onClick={() => {
              onNavigate('privacy');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-700 text-sm font-medium transition-colors"
          >
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-slate-500" />
              <span>Privacy Policy</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <button
            onClick={() => {
              onNavigate('splash');
              onClose();
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 text-slate-700 text-sm font-medium transition-colors"
          >
            <div className="flex items-center gap-3">
              <Truck className="w-5 h-5 text-slate-500" />
              <span>View Splash Screen</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 text-[11px] text-slate-500">
          <div className="flex items-center gap-1.5 text-slate-700 font-semibold mb-1">
            <MapPin className="w-3.5 h-3.5 text-[#0048A7]" />
            <span>Kanpur, Uttar Pradesh</span>
          </div>
          <p className="truncate">Shop No. 3, Naubasta, Kanpur</p>
          <p className="text-[10px] text-slate-400 mt-2 font-mono">App v1.0.0 · 24x7 Ready</p>
        </div>
      </div>
    </div>
  );
};
