import React from 'react';
import { Home, CalendarCheck, Phone, MoreHorizontal } from 'lucide-react';
import { BottomTabType } from '../types';

interface BottomNavBarProps {
  activeTab: BottomTabType;
  onTabChange: (tab: BottomTabType) => void;
  bookingCount?: number;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onTabChange,
  bookingCount = 0,
}) => {
  const tabs: { id: BottomTabType; label: string; icon: React.ReactNode }[] = [
    {
      id: 'home',
      label: 'Home',
      icon: <Home className="w-5 h-5" />,
    },
    {
      id: 'my_bookings',
      label: 'My Bookings',
      icon: (
        <div className="relative">
          <CalendarCheck className="w-5 h-5" />
          {bookingCount > 0 && (
            <span className="absolute -top-1.5 -right-2 bg-[#FF4E00] text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
              {bookingCount}
            </span>
          )}
        </div>
      ),
    },
    {
      id: 'contact',
      label: 'Contact',
      icon: <Phone className="w-5 h-5" />,
    },
    {
      id: 'more',
      label: 'More',
      icon: <MoreHorizontal className="w-5 h-5" />,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 select-none pb-[env(safe-area-inset-bottom)] shadow-[0_-4px_16px_rgba(0,0,0,0.06)]">
      <div className="max-w-md mx-auto grid grid-cols-4 h-16">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center min-h-[44px] py-1 transition-colors relative ${
                isActive
                  ? 'text-[#0048A7] font-semibold'
                  : 'text-slate-500 hover:text-slate-800 font-medium'
              }`}
            >
              <div
                className={`transition-transform duration-200 ${
                  isActive ? 'scale-110 text-[#0048A7]' : 'text-slate-400'
                }`}
              >
                {tab.icon}
              </div>
              <span className="text-[11px] tracking-tight mt-1 truncate">
                {tab.label}
              </span>
              {isActive && (
                <div className="absolute bottom-1 w-6 h-0.5 bg-[#0048A7] rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
