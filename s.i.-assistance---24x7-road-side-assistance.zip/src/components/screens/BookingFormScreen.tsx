import React, { useState } from 'react';
import {
  Car,
  User,
  Phone,
  CreditCard,
  MapPin,
  Send,
  ChevronRight,
  AlertCircle,
  Truck,
  Wrench,
  Fuel,
  Lock,
  Disc,
} from 'lucide-react';
import { COMMON_PROBLEMS } from '../../data/mockData';
import { Booking, ScreenType, VehicleCategory } from '../../types';

interface BookingFormScreenProps {
  onNavigate: (screen: ScreenType) => void;
  onSubmitBooking: (booking: Booking) => void;
  currentPickupLocation: string;
  onOpenLocationPicker: () => void;
  preselectedVehicle?: VehicleCategory;
  preselectedService?: string;
}

export const BookingFormScreen: React.FC<BookingFormScreenProps> = ({
  onNavigate,
  onSubmitBooking,
  currentPickupLocation,
  onOpenLocationPicker,
  preselectedVehicle = 'Car',
  preselectedService = 'Car Towing',
}) => {
  const [serviceType, setServiceType] = useState<string>(preselectedService || 'Car Towing');
  const [name, setName] = useState<string>('');
  const [mobile, setMobile] = useState<string>('');
  const [vehicleNumber, setVehicleNumber] = useState<string>('');
  const [destination, setDestination] = useState<string>('');
  const [problem, setProblem] = useState<string>('Engine Breakdown / Stalled');
  const [customProblem, setCustomProblem] = useState<string>('');
  const [showProblemPicker, setShowProblemPicker] = useState<boolean>(false);
  const [showServicePicker, setShowServicePicker] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const serviceOptions = [
    { title: 'Car Towing', icon: <Car className="w-4 h-4 text-[#0048A7]" /> },
    { title: 'Bike Towing', icon: <Truck className="w-4 h-4 text-[#0048A7]" /> },
    { title: 'SUV & Luxury Towing', icon: <Car className="w-4 h-4 text-[#0048A7]" /> },
    { title: 'Roadside Battery Jumpstart', icon: <Wrench className="w-4 h-4 text-[#0048A7]" /> },
    { title: 'Tyre Change / Puncture', icon: <Disc className="w-4 h-4 text-[#0048A7]" /> },
    { title: 'Emergency Fuel Delivery', icon: <Fuel className="w-4 h-4 text-[#0048A7]" /> },
    { title: 'Car Lockout Assist', icon: <Lock className="w-4 h-4 text-[#0048A7]" /> },
    { title: 'Hydra Crane Accident Recovery', icon: <Truck className="w-4 h-4 text-[#0048A7]" /> },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      setError('Please enter your full name');
      return;
    }
    if (!mobile.trim() || mobile.replace(/\D/g, '').length < 10) {
      setError('Please enter a valid 10-digit mobile number');
      return;
    }
    if (!vehicleNumber.trim()) {
      setError('Please enter your vehicle number (e.g. UP78AB1234)');
      return;
    }

    setError('');

    // Generate unique Booking ID matching SI-2025-XXXXX pattern
    const randomSeq = Math.floor(10000 + Math.random() * 90000);
    const bookingId = `SI-2025-${randomSeq}`;

    const now = new Date();
    const dateStr = now.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
    const timeStr = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
    const bookedOnStr = `${dateStr}, ${timeStr}`;

    const newBooking: Booking = {
      id: bookingId,
      serviceType: serviceType,
      vehicleCategory: preselectedVehicle,
      name: name.trim(),
      mobile: `+91 ${mobile.replace(/\D/g, '').slice(-10)}`,
      vehicleNumber: vehicleNumber.toUpperCase().trim(),
      pickupLocation: currentPickupLocation || 'Tidhakpur, Kanpur, Uttar Pradesh',
      destination: destination.trim() || 'Nearest Authorized Service Center',
      problem: customProblem.trim() || problem,
      status: 'Received',
      bookedOn: bookedOnStr,
      driverName: 'Assigned upon confirmation',
      timeline: [
        {
          step: 'Request Received',
          time: bookedOnStr,
          completed: true,
          active: true,
          notes: 'Booking recorded in Kanpur dispatch hub.',
        },
        {
          step: 'Confirmed',
          time: 'Verifying in 2 mins',
          completed: false,
          notes: 'Customer support verifying route availability.',
        },
        {
          step: 'Assigned',
          time: 'Pending confirmation',
          completed: false,
          notes: 'Assigning nearest tow truck pilot.',
        },
        {
          step: 'On the Way',
          time: 'Pending assignment',
          completed: false,
          notes: 'Driver dispatch & live location tracking.',
        },
        {
          step: 'Completed',
          time: 'Pending service',
          completed: false,
          notes: 'Roadside assistance delivery.',
        },
      ],
    };

    onSubmitBooking(newBooking);
    onNavigate('booking_confirmation');
  };

  return (
    <div className="pb-28 bg-[#F5F7FA] min-h-screen text-slate-900 select-none">
      <form onSubmit={handleSubmit} className="p-4 space-y-3.5">
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-red-700 text-xs font-semibold">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{error}</span>
          </div>
        )}

        {/* 1. Service Type Selector */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Service Type
          </label>
          <div
            onClick={() => setShowServicePicker(!showServicePicker)}
            className="w-full flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200 text-sm font-semibold cursor-pointer hover:border-blue-300 transition-colors shadow-sm"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center">
                <Car className="w-4 h-4 text-[#0048A7]" />
              </div>
              <span className="text-slate-900 font-bold">{serviceType}</span>
            </div>
            <ChevronRight
              className={`w-4 h-4 text-slate-400 transition-transform ${
                showServicePicker ? 'rotate-90' : ''
              }`}
            />
          </div>

          {showServicePicker && (
            <div className="mt-1.5 p-1 bg-white rounded-xl border border-slate-200 shadow-lg space-y-0.5">
              {serviceOptions.map((opt, i) => (
                <button
                  type="button"
                  key={i}
                  onClick={() => {
                    setServiceType(opt.title);
                    setShowServicePicker(false);
                  }}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg text-left transition-colors ${
                    serviceType === opt.title
                      ? 'bg-blue-50 text-[#0048A7]'
                      : 'hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  {opt.icon}
                  <span>{opt.title}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 2. Name */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Name
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <User className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0048A7]/30 focus:border-[#0048A7] shadow-sm font-medium"
            />
          </div>
        </div>

        {/* 3. Mobile Number */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Mobile Number
          </label>
          <div className="relative flex">
            <div className="inline-flex items-center gap-1 px-3 bg-slate-100 border border-r-0 border-slate-200 rounded-l-xl text-xs font-bold text-slate-700">
              <Phone className="w-3.5 h-3.5 text-slate-500" />
              <span>+91</span>
            </div>
            <input
              type="tel"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              placeholder="98765 43210"
              maxLength={10}
              className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-r-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0048A7]/30 focus:border-[#0048A7] shadow-sm font-medium"
            />
          </div>
        </div>

        {/* 4. Vehicle Number */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Vehicle Number
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <CreditCard className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={vehicleNumber}
              onChange={(e) => setVehicleNumber(e.target.value.toUpperCase())}
              placeholder="UP78AB1234"
              maxLength={12}
              className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold tracking-wide uppercase text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0048A7]/30 focus:border-[#0048A7] shadow-sm"
            />
          </div>
        </div>

        {/* 5. Pickup Location */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Pickup Location
          </label>
          <div
            onClick={onOpenLocationPicker}
            className="w-full flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200 text-sm cursor-pointer hover:border-blue-300 transition-colors shadow-sm"
          >
            <div className="flex items-center gap-2 min-w-0 pr-2">
              <MapPin className="w-4 h-4 text-red-500 shrink-0" />
              <span className="text-xs font-bold text-slate-800 truncate">
                {currentPickupLocation || 'Use Current Location'}
              </span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
          </div>
        </div>

        {/* 6. Destination (Optional) */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Destination (Optional)
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <MapPin className="w-4 h-4 text-slate-400" />
            </div>
            <input
              type="text"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="Enter destination (e.g., Authorized Workshop)"
              className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0048A7]/30 focus:border-[#0048A7] shadow-sm font-medium"
            />
          </div>
        </div>

        {/* 7. Problem / Description */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            Problem / Description
          </label>
          <div
            onClick={() => setShowProblemPicker(!showProblemPicker)}
            className="w-full flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200 text-sm cursor-pointer hover:border-blue-300 transition-colors shadow-sm"
          >
            <span className="text-xs font-semibold text-slate-800 truncate">
              {customProblem || problem}
            </span>
            <ChevronRight
              className={`w-4 h-4 text-slate-400 transition-transform ${
                showProblemPicker ? 'rotate-90' : ''
              }`}
            />
          </div>

          {showProblemPicker && (
            <div className="mt-1.5 p-2 bg-white rounded-xl border border-slate-200 shadow-lg space-y-1">
              <p className="text-[10px] uppercase font-bold text-slate-400 px-2 py-0.5">
                Common Roadside Issues
              </p>
              <div className="max-h-36 overflow-y-auto space-y-0.5">
                {COMMON_PROBLEMS.map((prob, i) => (
                  <button
                    type="button"
                    key={i}
                    onClick={() => {
                      setProblem(prob);
                      setCustomProblem('');
                      setShowProblemPicker(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                      problem === prob && !customProblem
                        ? 'bg-blue-50 text-[#0048A7] font-bold'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {prob}
                  </button>
                ))}
              </div>
              <div className="pt-2 border-t border-slate-100">
                <input
                  type="text"
                  placeholder="Or describe custom problem..."
                  value={customProblem}
                  onChange={(e) => setCustomProblem(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                />
              </div>
            </div>
          )}
        </div>

        {/* Submit Booking Button */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full h-12 rounded-xl bg-[#0048A7] hover:bg-[#003c8c] text-white font-bold text-sm shadow-md shadow-blue-900/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>Submit Booking</span>
          </button>
        </div>
      </form>
    </div>
  );
};
