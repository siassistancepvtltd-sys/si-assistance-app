import React from 'react';
import {
  PhoneCall,
  MessageCircle,
  Truck,
  Wrench,
  Car,
  Lock,
  Fuel,
  Disc,
  ChevronRight,
  ShieldAlert,
  ArrowRight,
  Clock,
  Sparkles,
} from 'lucide-react';
import { COMPANY_INFO, SERVICES } from '../../data/mockData';
import { Booking, ScreenType } from '../../types';

interface HomeScreenProps {
  onNavigate: (screen: ScreenType) => void;
  onSelectService: (serviceId: string) => void;
  activeBooking?: Booking | null;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  onSelectService,
  activeBooking,
}) => {
  // The 6 services from the screenshot grid
  const gridServices = [
    {
      id: 'towing-vehicle-recovery',
      title: 'Towing & Recovery',
      icon: <Truck className="w-7 h-7 text-[#0048A7]" />,
      screen: 'service_details' as ScreenType,
    },
    {
      id: 'roadside-assistance',
      title: 'Roadside Assistance',
      icon: <Wrench className="w-7 h-7 text-[#0048A7]" />,
      screen: 'service_details' as ScreenType,
    },
    {
      id: 'car-carrier-transport',
      title: 'Car Carrier',
      icon: <Car className="w-7 h-7 text-[#0048A7]" />,
      screen: 'service_details' as ScreenType,
    },
    {
      id: 'roadside-assistance',
      title: 'Lockout Service',
      icon: <Lock className="w-7 h-7 text-[#0048A7]" />,
      screen: 'service_details' as ScreenType,
    },
    {
      id: 'roadside-assistance',
      title: 'Fuel Delivery',
      icon: <Fuel className="w-7 h-7 text-[#0048A7]" />,
      screen: 'service_details' as ScreenType,
    },
    {
      id: 'roadside-assistance',
      title: 'Tyre Change',
      icon: <Disc className="w-7 h-7 text-[#0048A7]" />,
      screen: 'service_details' as ScreenType,
    },
  ];

  return (
    <div className="pb-24 bg-[#F5F7FA] min-h-screen text-slate-900 select-none">
      {/* Hero Need Roadside Help Banner */}
      <div className="p-4 pt-3">
        <div className="relative rounded-2xl overflow-hidden shadow-lg bg-gradient-to-r from-[#003882] to-[#0a4699] text-white">
          {/* Background image overlay */}
          <div className="absolute inset-0 opacity-40 mix-blend-luminosity">
            <img
              src="/src/assets/images/hero_flatbed_towing_1793264395416.jpg"
              alt="Roadside help background"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-r from-[#002B66]/90 via-[#003882]/75 to-transparent" />

          <div className="relative p-5 z-10">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-400/20 text-amber-300 text-[11px] font-semibold mb-2.5 border border-amber-400/30">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>24x7 Immediate Dispatch</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight leading-snug">
              Need Roadside Help?
            </h2>
            <p className="text-xs text-blue-100 font-medium mt-1">
              Car & Bike Towing · Recovery · Transport
            </p>

            <div className="mt-4 flex items-center gap-3">
              <button
                onClick={() => onNavigate('booking_form')}
                className="px-4 py-2 bg-white text-[#0048A7] rounded-xl text-xs font-bold shadow hover:bg-blue-50 active:scale-95 transition-all flex items-center gap-1.5"
              >
                <span>Book Service Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onNavigate('services_list')}
                className="px-3 py-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-xl text-xs font-semibold backdrop-blur-sm active:scale-95 transition-all"
              >
                View Services
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency & WhatsApp Quick Action Dual Buttons */}
      <div className="px-4 grid grid-cols-2 gap-3">
        {/* Red / Orange Emergency Call Button */}
        <a
          href={`tel:${COMPANY_INFO.primaryPhoneRaw}`}
          className="flex items-center p-3 rounded-2xl bg-gradient-to-br from-[#FF4E00] to-[#E02612] text-white shadow-md active:scale-[0.98] transition-transform"
        >
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center shrink-0 mr-2.5 border border-white/25">
            <PhoneCall className="w-5 h-5 text-white animate-bounce-subtle" />
          </div>
          <div className="min-w-0">
            <p className="text-[11px] uppercase tracking-wider font-extrabold text-white/90">
              Emergency Call
            </p>
            <p className="text-[12px] font-bold text-white tracking-tight truncate">
              {COMPANY_INFO.primaryPhone}
            </p>
          </div>
        </a>

        {/* Green WhatsApp Booking Button */}
        <a
          href={`https://wa.me/${COMPANY_INFO.whatsappPhoneRaw.replace('+', '')}?text=Hello%20SI%20Assistance,%20I%20need%20roadside%20assistance.%20Please%20send%20help.`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center p-3 rounded-2xl bg-gradient-to-br from-[#00A859] to-[#028A4B] text-white shadow-md active:scale-[0.98] transition-transform"
        >
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center shrink-0 mr-2.5 border border-white/25">
            <MessageCircle className="w-5 h-5 text-white" />
          </div>
          <div className="min-w-0">
            <p className="text-[11px] uppercase tracking-wider font-extrabold text-white/90">
              WhatsApp Booking
            </p>
            <p className="text-[12px] font-bold text-white tracking-tight truncate">
              Send Your Details
            </p>
          </div>
        </a>
      </div>

      {/* Active Booking Live Tracker Card (if available) */}
      {activeBooking && (
        <div className="px-4 mt-4">
          <div
            onClick={() => onNavigate('booking_status')}
            className="p-3.5 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl shadow-sm flex items-center justify-between cursor-pointer hover:border-blue-300 transition-all active:scale-[0.99]"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#0048A7] text-white flex items-center justify-center shrink-0">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900">
                    Active Booking: {activeBooking.id}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {activeBooking.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 mt-0.5 truncate max-w-[200px]">
                  {activeBooking.serviceType} · {activeBooking.pickupLocation}
                </p>
              </div>
            </div>
            <div className="flex items-center text-[#0048A7] text-xs font-bold shrink-0">
              <span>Track</span>
              <ChevronRight className="w-4 h-4 ml-0.5" />
            </div>
          </div>
        </div>
      )}

      {/* Our Services Section */}
      <div className="px-4 mt-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Our Services
          </h3>
          <button
            onClick={() => onNavigate('services_list')}
            className="text-xs font-bold text-[#0048A7] hover:underline flex items-center"
          >
            <span>View All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 6 Grid Icons Cards matching UI screenshot */}
        <div className="grid grid-cols-3 gap-3">
          {gridServices.map((service, index) => (
            <button
              key={index}
              onClick={() => {
                onSelectService(service.id);
                onNavigate(service.screen);
              }}
              className="flex flex-col items-center justify-center p-3 bg-white rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 hover:border-blue-200 active:scale-95 transition-all text-center group min-h-[105px]"
            >
              <div className="w-13 h-13 rounded-2xl bg-blue-50/80 flex items-center justify-center mb-2 group-hover:bg-blue-100/80 transition-colors">
                {service.icon}
              </div>
              <span className="text-xs font-bold text-slate-800 leading-tight">
                {service.title}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Quick Booking CTA Strip */}
      <div className="px-4 mt-6">
        <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900">Breakdown on Highway?</p>
              <p className="text-[11px] text-slate-500">Average dispatch time: under 15 mins</p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('booking_form')}
            className="px-3.5 py-2 bg-[#0048A7] hover:bg-[#003c8c] text-white text-xs font-bold rounded-xl shadow-sm shrink-0 active:scale-95 transition-all"
          >
            Book Now
          </button>
        </div>
      </div>

      {/* Why Choose S.I. Assistance Banner */}
      <div className="px-4 mt-5">
        <div className="p-4 rounded-2xl bg-[#002D6B] text-white shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold tracking-wider text-amber-300 uppercase">
              {COMPANY_INFO.fullName}
            </span>
            <span className="text-[11px] text-blue-200 font-medium">Pan India Network</span>
          </div>
          <p className="text-xs text-white/90 leading-relaxed">
            Fast, safe, and professional recovery equipment with certified hydraulic tilt-beds
            and verified mechanics stationed across Kanpur & Uttar Pradesh highways.
          </p>
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-blue-200 font-semibold">
            <span>✓ Damage-Free Towing</span>
            <span>✓ 24x7 Live Dispatch</span>
            <span>✓ Transparent Rates</span>
          </div>
        </div>
      </div>
    </div>
  );
};
