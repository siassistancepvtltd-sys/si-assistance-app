import React, { useState } from 'react';
import {
  Check,
  PhoneCall,
  Clock,
  Truck,
  Car,
  MapPin,
  User,
  ShieldCheck,
  Star,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { COMPANY_INFO } from '../../data/mockData';
import { Booking, BookingStatusStep, ScreenType } from '../../types';

interface BookingStatusTrackingScreenProps {
  booking: Booking | null;
  onUpdateBookingStatus: (bookingId: string, nextStatus: Booking['status']) => void;
  onNavigate: (screen: ScreenType) => void;
}

export const BookingStatusTrackingScreen: React.FC<BookingStatusTrackingScreenProps> = ({
  booking,
  onUpdateBookingStatus,
  onNavigate,
}) => {
  const [driverCallModal, setDriverCallModal] = useState<boolean>(false);
  const [rating, setRating] = useState<number>(5);
  const [feedbackSent, setFeedbackSent] = useState<boolean>(false);

  const fallbackBooking: Booking = {
    id: 'SI-2025-00123',
    serviceType: 'Car Towing',
    vehicleCategory: 'Car',
    name: 'Suresh Verma',
    mobile: '+91 98765 43210',
    vehicleNumber: 'UP78AB1234',
    pickupLocation: 'Tidhakpur, Kanpur',
    problem: 'Engine breakdown on highway',
    status: 'On the Way',
    bookedOn: '10 Apr 2025, 09:45 AM',
    driverName: 'Rajesh Kumar (Pilot)',
    driverPhone: COMPANY_INFO.primaryPhone,
    driverVehicle: 'Hydraulic Flatbed (UP78-T-4412)',
    estimatedArrival: '12 mins (3.4 km away)',
    timeline: [
      { step: 'Request Received' as BookingStatusStep, time: '10 Apr 2025, 09:45 AM', completed: true, notes: 'Emergency booking registered.' },
      { step: 'Confirmed' as BookingStatusStep, time: '10 Apr 2025, 09:50 AM', completed: true, notes: 'Support verified vehicle location.' },
      { step: 'Assigned' as BookingStatusStep, time: '10 Apr 2025, 10:15 AM', completed: true, notes: 'Driver Rajesh Kumar assigned.' },
      { step: 'On the Way' as BookingStatusStep, time: '10 Apr 2025, 10:40 AM', completed: true, active: true, notes: 'Flatbed en route.' },
      { step: 'Completed' as BookingStatusStep, time: 'Waiting for your feedback', completed: false, notes: 'Waiting for service delivery.' },
    ],
  };

  const currentBooking = booking || fallbackBooking;

  const stepsOrder: BookingStatusStep[] = [
    'Request Received',
    'Confirmed',
    'Assigned',
    'On the Way',
    'Completed',
  ];

  // Advance simulation
  const handleAdvanceStatus = () => {
    const statusMap: Record<Booking['status'], Booking['status']> = {
      Received: 'Confirmed',
      Confirmed: 'Assigned',
      Assigned: 'On the Way',
      'On the Way': 'Completed',
      Completed: 'Received',
    };
    const next = statusMap[currentBooking.status] || 'Completed';
    onUpdateBookingStatus(currentBooking.id, next);
  };

  return (
    <div className="pb-28 bg-[#F5F7FA] min-h-screen text-slate-900 select-none">
      {/* Top Booking Summary Header */}
      <div className="p-4 pb-2">
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-bold uppercase tracking-wider">
              <span>Booking</span>
              <span>·</span>
              <span className="font-mono text-slate-700">{currentBooking.id}</span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 mt-0.5">
              {currentBooking.serviceType}
            </h3>
            <p className="text-xs text-slate-500 font-mono">
              Vehicle: {currentBooking.vehicleNumber}
            </p>
          </div>

          <div className="text-right">
            <span
              className={`text-[11px] font-bold px-2.5 py-1 rounded-full inline-block ${
                currentBooking.status === 'Completed'
                  ? 'bg-slate-100 text-slate-700'
                  : currentBooking.status === 'On the Way'
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {currentBooking.status}
            </span>
            <p className="text-[10px] text-slate-400 mt-1 font-medium">
              Kanpur Dispatch
            </p>
          </div>
        </div>
      </div>

      {/* Driver / ETA Card (Active when On the Way or Assigned) */}
      {currentBooking.status === 'On the Way' && (
        <div className="px-4 py-1">
          <div className="bg-gradient-to-r from-blue-900 to-[#0048A7] text-white rounded-2xl p-4 shadow-md flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">
                  {currentBooking.driverName || 'Rajesh Kumar (Pilot)'}
                </p>
                <p className="text-[11px] text-sky-200">
                  {currentBooking.driverVehicle || 'Flatbed Unit UP78-T-4412'}
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-amber-300 font-bold block uppercase tracking-wider">
                Live ETA
              </span>
              <span className="text-xs font-black text-white">
                {currentBooking.estimatedArrival || '~12 mins'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Vertical Stepper Container */}
      <div className="p-4 pt-2">
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
          <div className="space-y-6 relative">
            {/* Timeline Vertical Continuous Line */}
            <div className="absolute top-3 left-[17px] bottom-3 w-0.5 bg-slate-200 -z-0" />

            {currentBooking.timeline.map((stepItem, index) => {
              const isCompleted = stepItem.completed;
              const isActive = stepItem.active;

              return (
                <div key={index} className="relative flex items-start gap-3.5 z-10">
                  {/* Circle Check Icon / Pending Bullet */}
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 border-2 transition-all ${
                      isCompleted
                        ? 'bg-[#00A859] border-[#00A859] text-white shadow-sm'
                        : isActive
                        ? 'bg-amber-500 border-amber-500 text-white shadow-sm animate-pulse'
                        : 'bg-white border-slate-300 text-slate-300'
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="w-5 h-5 stroke-[3]" />
                    ) : (
                      <div className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                    )}
                  </div>

                  {/* Step Description & Time */}
                  <div className="min-w-0 flex-1 pt-1">
                    <div className="flex items-center justify-between">
                      <h4
                        className={`text-sm font-bold tracking-tight ${
                          isCompleted
                            ? 'text-slate-900'
                            : isActive
                            ? 'text-[#0048A7]'
                            : 'text-slate-400'
                        }`}
                      >
                        {stepItem.step}
                      </h4>
                    </div>

                    <p className="text-xs text-slate-500 mt-0.5 font-medium">
                      {stepItem.time}
                    </p>

                    {stepItem.notes && (
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {stepItem.notes}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Completion Feedback Modal / Section if Completed */}
      {currentBooking.status === 'Completed' && (
        <div className="px-4 py-2">
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-center">
            <ShieldCheck className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-900">
              Assistance Completed Successfully!
            </h4>
            <p className="text-xs text-slate-600 mt-0.5 mb-3">
              Vehicle was recovered and delivered safely. How was your experience?
            </p>

            {!feedbackSent ? (
              <div>
                <div className="flex justify-center gap-1.5 mb-3">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setRating(star)}
                      className="p-1 hover:scale-110 transition-transform"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= rating
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setFeedbackSent(true)}
                  className="px-4 py-1.5 bg-[#00A859] text-white text-xs font-bold rounded-xl shadow-sm"
                >
                  Submit Feedback
                </button>
              </div>
            ) : (
              <p className="text-xs font-bold text-emerald-700">
                ✓ Thank you for trusting S.I.Assistance!
              </p>
            )}
          </div>
        </div>
      )}

      {/* Testing & Demonstration Tools */}
      <div className="px-4 mt-2">
        <div className="p-3 bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-slate-600 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Interactive Simulator:</span>
          </div>
          <button
            onClick={handleAdvanceStatus}
            className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 text-[11px] font-bold rounded-lg shadow-2xs active:scale-95 transition-all flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3 text-[#0048A7]" />
            <span>Next Status Step</span>
          </button>
        </div>
      </div>

      {/* Sticky Bottom Call Driver Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-md border-t border-slate-200 z-30 max-w-md mx-auto">
        <a
          href={`tel:${COMPANY_INFO.primaryPhoneRaw}`}
          onClick={() => setDriverCallModal(true)}
          className="w-full h-12 rounded-xl bg-[#0048A7] hover:bg-[#003c8c] text-white font-bold text-sm shadow-md shadow-blue-900/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
          <PhoneCall className="w-4 h-4 text-white" />
          <span>Call Driver (+91 7800045524)</span>
        </a>
      </div>
    </div>
  );
};
