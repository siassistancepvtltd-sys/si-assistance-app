import React, { useState } from 'react';
import {
  HelpCircle,
  FileText,
  Shield,
  Star,
  Share2,
  Info,
  ChevronRight,
  X,
  Check,
  Truck,
  Heart,
} from 'lucide-react';
import { FAQS, COMPANY_INFO } from '../../data/mockData';
import { ScreenType } from '../../types';

interface MoreSettingsScreenProps {
  onNavigate: (screen: ScreenType) => void;
}

export const MoreSettingsScreen: React.FC<MoreSettingsScreenProps> = ({
  onNavigate,
}) => {
  const [activeModal, setActiveModal] = useState<
    'none' | 'rate' | 'share' | 'faqs' | 'terms' | 'privacy'
  >('none');
  const [ratingVal, setRatingVal] = useState<number>(5);
  const [ratingComment, setRatingComment] = useState<string>('');
  const [ratingSubmitted, setRatingSubmitted] = useState<boolean>(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);
  const [copyLinkNotice, setCopyLinkNotice] = useState<boolean>(false);

  const handleShareApp = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'S.I. Assistance - 24x7 Road Side Assistance',
          text: 'Emergency car towing, vehicle recovery, and 24x7 roadside assistance in Kanpur and across India.',
          url: window.location.href,
        });
      } catch {
        // Ignored if cancelled
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopyLinkNotice(true);
      setTimeout(() => setCopyLinkNotice(false), 2500);
    }
  };

  return (
    <div className="pb-24 bg-[#F5F7FA] min-h-screen text-slate-900 select-none">
      <div className="p-4 space-y-2">
        {/* Menu Row 1: FAQs */}
        <button
          onClick={() => setActiveModal('faqs')}
          className="w-full flex items-center justify-between p-3.5 bg-white rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.03)] border border-slate-100 hover:border-blue-200 transition-colors group text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#0048A7] flex items-center justify-center shrink-0">
              <HelpCircle className="w-5 h-5" />
            </div>
            <span className="text-sm font-bold text-slate-800">FAQs</span>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-[#0048A7] transition-colors" />
        </button>

        {/* Menu Row 2: Terms & Conditions */}
        <button
          onClick={() => setActiveModal('terms')}
          className="w-full flex items-center justify-between p-3.5 bg-white rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.03)] border border-slate-100 hover:border-blue-200 transition-colors group text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#0048A7] flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-sm font-bold text-slate-800">
              Terms & Conditions
            </span>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-[#0048A7] transition-colors" />
        </button>

        {/* Menu Row 3: Privacy Policy */}
        <button
          onClick={() => setActiveModal('privacy')}
          className="w-full flex items-center justify-between p-3.5 bg-white rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.03)] border border-slate-100 hover:border-blue-200 transition-colors group text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#0048A7] flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5" />
            </div>
            <span className="text-sm font-bold text-slate-800">Privacy Policy</span>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-[#0048A7] transition-colors" />
        </button>

        {/* Menu Row 4: Rate Us */}
        <button
          onClick={() => {
            setActiveModal('rate');
            setRatingSubmitted(false);
          }}
          className="w-full flex items-center justify-between p-3.5 bg-white rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.03)] border border-slate-100 hover:border-blue-200 transition-colors group text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center shrink-0">
              <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
            </div>
            <span className="text-sm font-bold text-slate-800">Rate Us</span>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-[#0048A7] transition-colors" />
        </button>

        {/* Menu Row 5: Share App */}
        <button
          onClick={handleShareApp}
          className="w-full flex items-center justify-between p-3.5 bg-white rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.03)] border border-slate-100 hover:border-blue-200 transition-colors group text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#0048A7] flex items-center justify-center shrink-0">
              <Share2 className="w-5 h-5" />
            </div>
            <span className="text-sm font-bold text-slate-800">Share App</span>
          </div>
          <div className="flex items-center gap-1 text-slate-400 text-xs">
            {copyLinkNotice && (
              <span className="text-emerald-600 font-bold">Link copied!</span>
            )}
            <ChevronRight className="w-5 h-5 group-hover:text-[#0048A7] transition-colors" />
          </div>
        </button>

        {/* Menu Row 6: App Version */}
        <div className="w-full flex items-center justify-between p-3.5 bg-white rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.03)] border border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
              <Info className="w-5 h-5" />
            </div>
            <span className="text-sm font-bold text-slate-800">App Version</span>
          </div>
          <span className="text-xs font-mono font-bold text-slate-500">v1.0.0</span>
        </div>

        {/* Quick link to Splash Screen */}
        <div className="pt-4">
          <button
            onClick={() => onNavigate('splash')}
            className="w-full py-3 bg-white border border-slate-200 text-slate-700 hover:text-[#0048A7] text-xs font-bold rounded-2xl shadow-sm flex items-center justify-center gap-2"
          >
            <Truck className="w-4 h-4 text-[#0048A7]" />
            <span>Show Splash Screen Again</span>
          </button>
        </div>

        {/* Footer info */}
        <div className="text-center pt-6 text-[11px] text-slate-400">
          <p className="font-bold text-slate-600">{COMPANY_INFO.fullName}</p>
          <p className="mt-0.5">Kanpur, Uttar Pradesh · 24x7 Roadside Assistance</p>
        </div>
      </div>

      {/* FAQs Modal */}
      {activeModal === 'faqs' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-3">
          <div className="w-full max-w-md bg-white rounded-2xl p-5 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Frequently Asked Questions</h3>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-3 divide-y divide-slate-100">
              {FAQS.map((faq, idx) => (
                <div key={idx} className="py-3">
                  <button
                    onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                    className="w-full text-left flex justify-between items-start gap-2 font-bold text-xs text-slate-800"
                  >
                    <span>{faq.q}</span>
                    <span className="text-[#0048A7] shrink-0">
                      {expandedFaq === idx ? '−' : '+'}
                    </span>
                  </button>
                  {expandedFaq === idx && (
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed bg-slate-50 p-2.5 rounded-lg">
                      {faq.a}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Terms & Conditions Modal */}
      {activeModal === 'terms' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-3">
          <div className="w-full max-w-md bg-white rounded-2xl p-5 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Terms & Conditions</h3>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-3 space-y-3 text-xs text-slate-600 leading-relaxed">
              <p>
                <strong>1. Service Dispatch:</strong> S.I.Assistance Pvt Ltd operates 24×7
                emergency vehicle towing and assistance. Dispatch arrival times depend on road
                conditions and traffic.
              </p>
              <p>
                <strong>2. Vehicle Inspection:</strong> Drivers document vehicle condition prior
                to flatbed loading to guarantee damage-free towing transit.
              </p>
              <p>
                <strong>3. Transparent Pricing:</strong> Standard rates apply based on distance
                and service category. Official digital receipts are issued for all bookings.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Privacy Policy Modal */}
      {activeModal === 'privacy' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-3">
          <div className="w-full max-w-md bg-white rounded-2xl p-5 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Privacy Policy</h3>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-3 space-y-3 text-xs text-slate-600 leading-relaxed">
              <p>
                We respect your personal privacy. Customer phone numbers, vehicle registration
                details, and pickup coordinates are strictly used for dispatching roadside
                assistance and connecting you with the assigned driver.
              </p>
              <p>
                We do not sell, rent, or distribute user information to third-party marketing
                networks.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Rate Us Modal */}
      {activeModal === 'rate' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-3">
          <div className="w-full max-w-md bg-white rounded-2xl p-5 shadow-2xl text-center">
            <div className="flex justify-end">
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {!ratingSubmitted ? (
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-500 mx-auto flex items-center justify-center">
                  <Heart className="w-6 h-6 fill-amber-400 text-amber-400" />
                </div>
                <h3 className="text-base font-bold text-slate-900">Rate S.I.Assistance</h3>
                <p className="text-xs text-slate-500">
                  How would you rate our roadside response and towing service?
                </p>

                <div className="flex justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setRatingVal(star)}
                      className="p-1 hover:scale-125 transition-transform"
                    >
                      <Star
                        className={`w-7 h-7 ${
                          star <= ratingVal
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-200'
                        }`}
                      />
                    </button>
                  ))}
                </div>

                <textarea
                  value={ratingComment}
                  onChange={(e) => setRatingComment(e.target.value)}
                  placeholder="Tell us what you liked or how we can improve..."
                  rows={2}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                />

                <button
                  onClick={() => setRatingSubmitted(true)}
                  className="w-full py-2.5 bg-[#0048A7] text-white text-xs font-bold rounded-xl shadow-sm"
                >
                  Submit Review
                </button>
              </div>
            ) : (
              <div className="py-4 space-y-2">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center">
                  <Check className="w-6 h-6 stroke-[3]" />
                </div>
                <h4 className="text-sm font-bold text-slate-900">Thank you for your rating!</h4>
                <p className="text-xs text-slate-500">
                  Your review helps us keep Kanpur and Indian highways moving safely.
                </p>
                <button
                  onClick={() => setActiveModal('none')}
                  className="mt-2 px-4 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Close
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
