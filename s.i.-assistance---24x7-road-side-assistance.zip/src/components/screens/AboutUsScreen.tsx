import React from 'react';
import { PhoneCall, Users, Globe2, Truck, ArrowRight, ShieldCheck, Award } from 'lucide-react';
import { COMPANY_INFO } from '../../data/mockData';
import { ScreenType } from '../../types';

interface AboutUsScreenProps {
  onNavigate: (screen: ScreenType) => void;
}

export const AboutUsScreen: React.FC<AboutUsScreenProps> = ({ onNavigate }) => {
  return (
    <div className="pb-24 bg-[#F5F7FA] min-h-screen text-slate-900 select-none">
      {/* Top Fleet Image */}
      <div className="relative aspect-[16/10] bg-slate-900 overflow-hidden shadow-sm">
        <img
          src="/src/assets/images/service_accident_recovery_crane_1793264398331.jpg"
          alt="S.I.Assistance Fleet"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
        <div className="absolute bottom-3 left-4 right-4">
          <span className="text-[11px] font-bold tracking-wide bg-amber-400 text-slate-950 px-2 py-0.5 rounded uppercase">
            Certified Heavy Fleet
          </span>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Company Title Banner Card */}
        <div className="bg-[#002D6B] text-white rounded-2xl p-4 shadow-sm text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-white/10 border border-white/20 mb-2">
            <Truck className="w-6 h-6 text-sky-400" />
          </div>
          <h2 className="text-xl font-extrabold uppercase tracking-tight text-white">
            {COMPANY_INFO.name}
          </h2>
          <p className="text-[11px] font-bold tracking-widest text-sky-300 uppercase mt-0.5">
            {COMPANY_INFO.subheading}
          </p>
          <p className="text-xs text-amber-300 font-semibold mt-2 italic font-['Noto_Sans_Devanagari',sans-serif]">
            "{COMPANY_INFO.taglineHindi}"
          </p>
        </div>

        {/* About Prose Card matching the exact text in screenshot */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 space-y-3">
          <p className="text-xs text-slate-700 leading-relaxed font-medium">
            <strong className="text-slate-900 font-bold">S.I.Assistance Pvt Ltd</strong> is a
            trusted name in roadside assistance and vehicle recovery services. We are committed
            to providing fast, safe and reliable support to our customers 24×7, across India.
          </p>
          <p className="text-xs text-slate-600 leading-relaxed">
            Headquartered in Kanpur, Uttar Pradesh, our modern recovery fleet includes hydraulic
            flatbeds, underlift tow vehicles, heavy hydra cranes, and specialized on-site repair
            vans capable of handling all types of passenger and commercial automobiles.
          </p>
        </div>

        {/* 3 Circular Feature Badges matching UI screenshot */}
        <div className="grid grid-cols-3 gap-2.5">
          {/* Badge 1: 24x7 Support */}
          <div className="bg-white rounded-2xl p-3 shadow-sm border border-slate-100 flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-[#0048A7] text-white flex items-center justify-center mb-2 shadow-sm">
              <PhoneCall className="w-5 h-5 text-amber-300" />
            </div>
            <span className="text-xs font-bold text-slate-900">24×7</span>
            <span className="text-[11px] text-slate-500 font-medium">Support</span>
          </div>

          {/* Badge 2: Experienced Team */}
          <div className="bg-white rounded-2xl p-3 shadow-sm border border-slate-100 flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-[#0048A7] text-white flex items-center justify-center mb-2 shadow-sm">
              <Users className="w-5 h-5 text-white" />
            </div>
            <span className="text-xs font-bold text-slate-900">Experienced</span>
            <span className="text-[11px] text-slate-500 font-medium">Team</span>
          </div>

          {/* Badge 3: Wide Network */}
          <div className="bg-white rounded-2xl p-3 shadow-sm border border-slate-100 flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-[#0048A7] text-white flex items-center justify-center mb-2 shadow-sm">
              <Globe2 className="w-5 h-5 text-sky-300" />
            </div>
            <span className="text-xs font-bold text-slate-900">Wide</span>
            <span className="text-[11px] text-slate-500 font-medium">Network</span>
          </div>
        </div>

        {/* Our Services Primary Blue Button */}
        <div className="pt-2">
          <button
            onClick={() => onNavigate('services_list')}
            className="w-full h-12 rounded-xl bg-[#0048A7] hover:bg-[#003c8c] text-white font-bold text-sm shadow-md shadow-blue-900/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <span>Our Services</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
