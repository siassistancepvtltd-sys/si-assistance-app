import React, { useState } from 'react';
import { Check, ShieldCheck, ArrowRight, PhoneCall, Sparkles } from 'lucide-react';
import { SERVICES, COMPANY_INFO } from '../../data/mockData';
import { ScreenType, VehicleCategory } from '../../types';

interface ServiceDetailsScreenProps {
  serviceId?: string;
  onNavigate: (screen: ScreenType) => void;
  onPreselectVehicle?: (category: VehicleCategory) => void;
}

export const ServiceDetailsScreen: React.FC<ServiceDetailsScreenProps> = ({
  serviceId = 'towing-vehicle-recovery',
  onNavigate,
  onPreselectVehicle,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<VehicleCategory>('Car');

  const service =
    SERVICES.find((s) => s.id === serviceId) || SERVICES[0];

  const categories: VehicleCategory[] = ['Car', 'Bike', 'SUV', 'Commercial'];

  const handleBookNow = () => {
    if (onPreselectVehicle) {
      onPreselectVehicle(selectedCategory);
    }
    onNavigate('booking_form');
  };

  return (
    <div className="pb-28 bg-[#F5F7FA] min-h-screen text-slate-900 select-none">
      {/* Top Banner Image */}
      <div className="relative aspect-[16/10] bg-slate-900 overflow-hidden shadow-sm">
        <img
          src={service.image}
          alt={service.title}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent" />
        <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-white">
          <span className="text-xs font-bold tracking-wide bg-blue-600/80 px-2.5 py-1 rounded-md backdrop-blur-sm">
            {service.title}
          </span>
          <span className="text-xs font-semibold bg-black/50 px-2 py-1 rounded-md backdrop-blur-sm text-amber-300">
            ★ 4.9 (4,800+ Assists)
          </span>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Vehicle Category Chips */}
        <div>
          <label className="block text-xs font-bold text-slate-600 mb-2 uppercase tracking-wider">
            Select Vehicle Type
          </label>
          <div className="grid grid-cols-4 gap-2">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`py-2 px-1 text-center rounded-xl text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-[#0048A7] text-white shadow-sm ring-2 ring-[#0048A7]/30 scale-[1.02]'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Service Features Checklist */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
          <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
            Included in this Service
          </h4>
          <div className="space-y-3">
            {service.features.map((feature, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-[#0048A7] text-white flex items-center justify-center shrink-0">
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                </div>
                <span className="text-sm font-semibold text-slate-800">
                  {feature}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* 24x7 Highlight Box */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-[#003882] to-[#0B52B0] text-white shadow-sm flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white leading-tight">
              Get Fast & Safe Towing Service
            </h4>
            <p className="text-xs text-blue-100 font-medium mt-0.5">
              24×7 Available across Kanpur & Highways
            </p>
          </div>
        </div>

        {/* Emergency Call Hotline Alternative */}
        <div className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-600 font-medium">Stuck in an urgent emergency?</span>
          <a
            href={`tel:${COMPANY_INFO.primaryPhoneRaw}`}
            className="text-red-600 font-bold hover:underline flex items-center gap-1"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Call Driver Now</span>
          </a>
        </div>
      </div>

      {/* Fixed / Sticky Bottom CTA Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-md border-t border-slate-200 z-30 max-w-md mx-auto">
        <button
          onClick={handleBookNow}
          className="w-full h-12 rounded-xl bg-[#0048A7] hover:bg-[#003b8a] text-white font-bold text-sm shadow-md shadow-blue-900/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
          <span>Book Now ({selectedCategory})</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
