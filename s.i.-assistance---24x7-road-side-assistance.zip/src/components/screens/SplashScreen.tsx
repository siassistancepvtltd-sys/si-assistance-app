import React from 'react';
import { Truck, Wrench, Shield, ArrowRight } from 'lucide-react';
import { COMPANY_INFO } from '../../data/mockData';

interface SplashScreenProps {
  onEnterApp: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onEnterApp }) => {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-[#003882] via-[#002860] to-[#001333] text-white flex flex-col justify-between p-6 select-none overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />

      {/* Top Branding Area */}
      <div className="flex flex-col items-center pt-8 z-10 text-center">
        {/* Circular Logo Badge */}
        <div className="relative w-28 h-28 mb-4">
          <div className="absolute inset-0 rounded-full border-2 border-dashed border-sky-400/50 animate-spin-slow" />
          <div className="w-full h-full rounded-full bg-gradient-to-tr from-[#0048A7] to-[#0072FF] p-1.5 shadow-[0_0_30px_rgba(0,114,255,0.4)] flex items-center justify-center border-2 border-white/20">
            <div className="w-full h-full rounded-full bg-[#00224f] flex flex-col items-center justify-center p-2 relative overflow-hidden">
              <Truck className="w-10 h-10 text-sky-400 mb-0.5 stroke-[1.8]" />
              <div className="w-10 h-0.5 bg-sky-400/40 rounded-full mt-1" />
            </div>
          </div>
        </div>

        {/* Title & Subheading */}
        <h1 className="text-3xl font-extrabold tracking-tight text-white uppercase drop-shadow-sm">
          {COMPANY_INFO.name}
        </h1>
        <p className="text-xs font-bold tracking-widest text-sky-300 uppercase mt-1">
          {COMPANY_INFO.subheading}
        </p>

        {/* Hindi Tagline */}
        <div className="mt-4 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/10">
          <p className="text-sm font-semibold text-amber-300 tracking-wide font-['Noto_Sans_Devanagari',sans-serif]">
            {COMPANY_INFO.taglineHindi}
          </p>
        </div>
      </div>

      {/* Hero Truck Image */}
      <div className="my-auto py-4 z-10">
        <div className="relative rounded-2xl overflow-hidden border border-white/15 shadow-2xl bg-slate-900/40 backdrop-blur-sm aspect-[16/10] group">
          <img
            src="/src/assets/images/hero_flatbed_towing_1793264395416.jpg"
            alt="S.I. Assistance Recovery Tow Truck"
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#001333] via-transparent to-transparent opacity-80" />
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs">
            <span className="font-semibold text-white/90 bg-black/40 px-2.5 py-1 rounded-md backdrop-blur-sm border border-white/10">
              ⚡ 24x7 Kanpur & All India
            </span>
            <span className="text-emerald-400 font-bold bg-black/40 px-2.5 py-1 rounded-md backdrop-blur-sm border border-white/10">
              ● Active Fleets
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Features & Action */}
      <div className="z-10 pb-6">
        {/* 3 Categories Icon Row matching screenshot */}
        <div className="grid grid-cols-3 gap-2 py-4 mb-4 border-t border-white/10">
          <div className="flex flex-col items-center text-center">
            <div className="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center text-sky-400 mb-1.5 border border-white/10">
              <Truck className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-white/90">Towing</span>
          </div>

          <div className="flex flex-col items-center text-center">
            <div className="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center text-sky-400 mb-1.5 border border-white/10">
              <Wrench className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-white/90">Roadside Help</span>
          </div>

          <div className="flex flex-col items-center text-center">
            <div className="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center text-sky-400 mb-1.5 border border-white/10">
              <Shield className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-white/90">Car Carrier</span>
          </div>
        </div>

        {/* Enter App Primary Button */}
        <button
          onClick={onEnterApp}
          className="w-full h-13 rounded-2xl bg-gradient-to-r from-[#0062E0] to-[#0048A7] hover:from-[#006dfa] hover:to-[#0054c2] text-white font-bold text-base shadow-[0_8px_25px_rgba(0,114,255,0.4)] flex items-center justify-center gap-2 border border-sky-400/30 active:scale-[0.98] transition-all"
        >
          <span>Get Roadside Assistance</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
