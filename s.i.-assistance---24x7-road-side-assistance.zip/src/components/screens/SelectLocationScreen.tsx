import React, { useState } from 'react';
import {
  MapPin,
  Crosshair,
  Search,
  Check,
  Navigation,
  Compass,
} from 'lucide-react';
import { POPULAR_LOCATIONS } from '../../data/mockData';

interface SelectLocationScreenProps {
  onSelectLocation: (locationStr: string) => void;
  onBack: () => void;
  initialLocation?: string;
}

export const SelectLocationScreen: React.FC<SelectLocationScreenProps> = ({
  onSelectLocation,
  onBack,
  initialLocation = 'Tidhakpur, Kanpur, Uttar Pradesh',
}) => {
  const [currentLocation, setCurrentLocation] = useState<string>(initialLocation);
  const [pinOffset, setPinOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [showManualModal, setShowManualModal] = useState<boolean>(false);
  const [manualInput, setManualInput] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLocating, setIsLocating] = useState<boolean>(false);

  const handleUseThisLocation = () => {
    onSelectLocation(currentLocation);
    onBack();
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualInput.trim()) {
      setCurrentLocation(manualInput.trim());
      setShowManualModal(false);
      onSelectLocation(manualInput.trim());
      onBack();
    }
  };

  const handleDetectGPS = () => {
    setIsLocating(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setIsLocating(false);
          // Set to actual coordinates formatted or Kanpur proximity
          const detected = `GPS (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}) - Near Kanpur`;
          setCurrentLocation(detected);
          setPinOffset({ x: 10, y: -15 });
        },
        () => {
          // Fallback if permission blocked or error
          setIsLocating(false);
          setCurrentLocation('Tidhakpur, Naubasta, Kanpur, Uttar Pradesh');
          setPinOffset({ x: 0, y: 0 });
        },
        { timeout: 5000 }
      );
    } else {
      setIsLocating(false);
      setCurrentLocation('Tidhakpur, Kanpur, Uttar Pradesh');
    }
  };

  const filteredLocations = POPULAR_LOCATIONS.filter((l) =>
    l.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="relative h-screen bg-slate-100 flex flex-col justify-between overflow-hidden select-none">
      {/* Search Bar Overlay */}
      <div className="absolute top-3 left-4 right-4 z-20">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Kanpur locality, bypass, or landmark..."
            className="w-full pl-9 pr-3 py-2 bg-white/95 backdrop-blur-md border border-slate-200/80 rounded-xl text-xs font-medium text-slate-800 shadow-md focus:outline-none focus:ring-2 focus:ring-[#0048A7]"
          />
        </div>

        {searchQuery && filteredLocations.length > 0 && (
          <div className="mt-1 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden divide-y divide-slate-100 max-h-48 overflow-y-auto">
            {filteredLocations.map((loc, i) => (
              <button
                key={i}
                onClick={() => {
                  setCurrentLocation(`${loc.name}, Uttar Pradesh`);
                  setSearchQuery('');
                }}
                className="w-full text-left px-3 py-2 text-xs hover:bg-blue-50 flex items-center justify-between text-slate-700"
              >
                <span>{loc.name}</span>
                <Navigation className="w-3.5 h-3.5 text-[#0048A7]" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Styled Interactive SVG Map Canvas */}
      <div
        className="relative flex-1 w-full bg-[#E8ECEF] overflow-hidden cursor-crosshair"
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const clickX = e.clientX - rect.left - rect.width / 2;
          const clickY = e.clientY - rect.top - rect.height / 2;
          setPinOffset({ x: clickX, y: clickY });
          // Cycle through or randomize slightly
          const randomLoc =
            POPULAR_LOCATIONS[
              Math.floor(Math.random() * POPULAR_LOCATIONS.length)
            ].name;
          setCurrentLocation(`${randomLoc}, Uttar Pradesh`);
        }}
      >
        <svg
          className="w-full h-full object-cover"
          viewBox="0 0 400 600"
          preserveAspectRatio="none"
        >
          <defs>
            <pattern
              id="grid-pattern"
              width="40"
              height="40"
              patternUnits="userSpaceOnUse"
            >
              <rect width="40" height="40" fill="#E6EDF2" />
              <path
                d="M 40 0 L 0 0 0 40"
                fill="none"
                stroke="#D7E1E8"
                strokeWidth="1"
              />
            </pattern>
          </defs>

          {/* Map Base Grid */}
          <rect width="100%" height="100%" fill="url(#grid-pattern)" />

          {/* Parks & River Zones */}
          <path
            d="M 20 80 Q 80 120 110 200 T 70 340 T 120 480"
            fill="none"
            stroke="#C5E8CF"
            strokeWidth="35"
            strokeLinecap="round"
          />
          <path
            d="M 260 40 Q 320 180 290 320 T 360 520"
            fill="none"
            stroke="#CFE6FA"
            strokeWidth="28"
            strokeLinecap="round"
          />

          {/* Major Highways & Arteries */}
          <path
            d="M -20 180 L 420 230"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="14"
          />
          <path
            d="M -20 180 L 420 230"
            fill="none"
            stroke="#FDBA74"
            strokeWidth="7"
          />

          <path
            d="M 190 -20 L 210 620"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="12"
          />
          <path
            d="M 190 -20 L 210 620"
            fill="none"
            stroke="#FED7AA"
            strokeWidth="6"
          />

          {/* Secondary streets */}
          <path
            d="M 80 40 L 320 540 M 340 100 L 40 500 M 0 350 L 400 320"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="5"
          />
          <path
            d="M 60 120 L 360 140 M 120 280 L 300 420 M 40 460 L 360 440"
            fill="none"
            stroke="#E2E8F0"
            strokeWidth="3"
          />

          {/* Locality Labels */}
          <text
            x="200"
            y="320"
            textAnchor="middle"
            fill="#475569"
            fontSize="14"
            fontWeight="700"
            fontFamily="sans-serif"
          >
            Tidhakpur
          </text>
          <text
            x="110"
            y="210"
            textAnchor="middle"
            fill="#64748B"
            fontSize="10"
            fontWeight="600"
          >
            Naubasta Bypass
          </text>
          <text
            x="280"
            y="440"
            textAnchor="middle"
            fill="#64748B"
            fontSize="10"
            fontWeight="600"
          >
            Barra Link Road
          </text>
        </svg>

        {/* Center / Offset Pin Marker */}
        <div
          className="absolute z-10 pointer-events-none transition-all duration-300 -translate-x-1/2 -translate-y-full"
          style={{
            top: `calc(50% + ${pinOffset.y}px)`,
            left: `calc(50% + ${pinOffset.x}px)`,
          }}
        >
          {/* Label Card */}
          <div className="bg-white/95 px-3 py-1 rounded-full shadow-lg border border-slate-200 text-[11px] font-bold text-slate-900 mb-1 flex items-center gap-1 whitespace-nowrap mx-auto">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <span>Your Location</span>
          </div>

          {/* Red Pin Icon */}
          <div className="w-10 h-10 text-red-600 mx-auto drop-shadow-md flex items-center justify-center">
            <MapPin className="w-9 h-9 fill-red-600 stroke-white stroke-2" />
          </div>
          {/* Pulse Ripple on Map Ground */}
          <div className="w-6 h-2 bg-red-600/30 rounded-full mx-auto -mt-1 blur-[1px] animate-pulse" />
        </div>

        {/* Floating GPS Re-Center Button */}
        <button
          onClick={handleDetectGPS}
          title="Detect Current Location"
          className="absolute bottom-6 right-4 z-10 w-11 h-11 bg-white rounded-full shadow-lg border border-slate-200 flex items-center justify-center text-slate-700 hover:text-[#0048A7] active:scale-95 transition-all"
        >
          <Crosshair
            className={`w-5 h-5 ${isLocating ? 'animate-spin text-[#0048A7]' : ''}`}
          />
        </button>
      </div>

      {/* Bottom Location Confirmation Sheet */}
      <div className="bg-white p-4 rounded-t-3xl shadow-[0_-8px_25px_rgba(0,0,0,0.08)] border-t border-slate-100 z-20 space-y-3">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-full bg-red-50 text-red-600 flex items-center justify-center shrink-0 mt-0.5 border border-red-100">
            <MapPin className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] uppercase tracking-wider font-extrabold text-slate-400">
              Current Location
            </p>
            <p className="text-sm font-bold text-slate-900 truncate">
              {currentLocation}
            </p>
          </div>
        </div>

        <button
          onClick={handleUseThisLocation}
          className="w-full h-12 rounded-xl bg-[#0048A7] hover:bg-[#003c8c] text-white font-bold text-sm shadow-md shadow-blue-900/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
          <Check className="w-4 h-4" />
          <span>Use This Location</span>
        </button>

        <div className="text-center pt-1">
          <button
            onClick={() => {
              setManualInput(currentLocation);
              setShowManualModal(true);
            }}
            className="text-xs font-bold text-[#0048A7] hover:underline"
          >
            Enter Address Manually
          </button>
        </div>
      </div>

      {/* Manual Address Input Modal */}
      {showManualModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl p-5 shadow-2xl animate-in slide-in-from-bottom-6">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Enter Exact Location
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Add landmark, shop number, or highway milestone.
            </p>
            <form onSubmit={handleManualSubmit} className="space-y-3">
              <input
                type="text"
                autoFocus
                value={manualInput}
                onChange={(e) => setManualInput(e.target.value)}
                placeholder="e.g. Near Naubasta Toll Plaza, Kanpur"
                className="w-full px-3 py-2.5 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-[#0048A7] focus:outline-none"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowManualModal(false)}
                  className="flex-1 py-2 text-xs font-bold text-slate-600 rounded-xl bg-slate-100 hover:bg-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-bold text-white rounded-xl bg-[#0048A7] hover:bg-blue-800"
                >
                  Save Address
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
