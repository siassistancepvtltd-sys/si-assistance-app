import React, { useState } from 'react';
import { Check, CheckCircle2, Copy, MessageCircle, ArrowRight, Home } from 'lucide-react';
import { COMPANY_INFO } from '../../data/mockData';
import { Booking, ScreenType } from '../../types';

interface BookingConfirmationScreenProps {
  booking: Booking | null;
  onNavigate: (screen: ScreenType) => void;
}

export const BookingConfirmationScreen: React.FC<BookingConfirmationScreenProps> = ({
  booking,
  onNavigate,
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  const bookingId = booking?.id || 'SI-2025-00123';
  const phone = booking?.mobile || '+91 7800045524';

  const handleCopyId = () => {
    navigator.clipboard.writeText(bookingId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="pb-16 bg-[#F5F7FA] min-h-screen text-slate-900 select-none flex flex-col justify-between p-4">
      <div className="pt-8 flex flex-col items-center text-center">
        {/* Big Green Success Circle */}
        <div className="w-20 h-20 rounded-full bg-[#00A859] text-white flex items-center justify-center shadow-lg shadow-emerald-600/30 mb-5 animate-in zoom-in-50 duration-300">
          <Check className="w-11 h-11 stroke-[3]" />
        </div>

        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
          Booking Submitted!
        </h2>
        <p className="text-xs text-slate-500 mt-1 max-w-xs font-medium">
          Our rapid roadside dispatch unit is preparing to assist you.
        </p>

        {/* Your Booking ID Card */}
        <div className="w-full mt-6 p-6 bg-white rounded-2xl border border-slate-100 shadow-sm text-center">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Your Booking ID
          </p>
          <div className="flex items-center justify-center gap-2 mt-2">
            <span className="text-2xl font-black text-[#0048A7] font-mono tracking-tight">
              {bookingId}
            </span>
            <button
              onClick={handleCopyId}
              title="Copy Booking ID"
              className="p-1.5 rounded-lg text-slate-400 hover:text-[#0048A7] hover:bg-blue-50 transition-colors"
            >
              {copied ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>
          </div>
          {copied && (
            <span className="text-[10px] text-emerald-600 font-bold mt-1 block">
              Copied to clipboard!
            </span>
          )}

          <div className="my-4 border-t border-slate-100" />

          <p className="text-xs text-slate-600 leading-relaxed font-medium">
            Your request has been sent to our team. We will contact you shortly.
          </p>
        </div>

        {/* WhatsApp Notification Card */}
        <a
          href={`https://wa.me/${COMPANY_INFO.whatsappPhoneRaw.replace('+', '')}?text=Hi,%20I%20have%20submitted%20booking%20${bookingId}.%20Please%20confirm%20my%20roadside%20assistance.`}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full mt-4 p-4 rounded-2xl bg-gradient-to-r from-emerald-50 to-green-50 border border-emerald-200 flex items-center gap-3.5 text-left active:scale-[0.99] transition-transform"
        >
          <div className="w-10 h-10 rounded-full bg-[#00A859] text-white flex items-center justify-center shrink-0 shadow-sm">
            <MessageCircle className="w-5 h-5 fill-current" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold text-slate-900 leading-snug">
              Details also sent to WhatsApp
            </p>
            <p className="text-xs font-bold text-emerald-700 font-mono mt-0.5">
              {COMPANY_INFO.primaryPhone}
            </p>
          </div>
          <ArrowRight className="w-4 h-4 text-emerald-600 shrink-0" />
        </a>
      </div>

      {/* Action Buttons */}
      <div className="pt-8 space-y-3">
        <button
          onClick={() => onNavigate('my_bookings')}
          className="w-full h-12 rounded-xl bg-[#0048A7] hover:bg-[#003c8c] text-white font-bold text-sm shadow-md shadow-blue-900/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
          <span>View My Bookings</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          onClick={() => onNavigate('home')}
          className="w-full py-2.5 text-center text-xs font-bold text-slate-600 hover:text-slate-900 transition-colors"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};
