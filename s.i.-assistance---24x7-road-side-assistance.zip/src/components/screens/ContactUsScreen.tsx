import React, { useState } from 'react';
import {
  PhoneCall,
  MessageCircle,
  MapPin,
  Mail,
  Globe,
  ExternalLink,
  Send,
  Check,
} from 'lucide-react';
import { COMPANY_INFO } from '../../data/mockData';

export const ContactUsScreen: React.FC = () => {
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryName.trim() || !inquiryPhone.trim()) return;
    setSubmitted(true);
    setTimeout(() => {
      setInquiryName('');
      setInquiryPhone('');
      setInquiryMessage('');
      setSubmitted(false);
    }, 4000);
  };

  return (
    <div className="pb-24 bg-[#F5F7FA] min-h-screen text-slate-900 select-none">
      <div className="p-4 space-y-3.5">
        {/* 1. Red Emergency Call Card */}
        <a
          href={`tel:${COMPANY_INFO.primaryPhoneRaw}`}
          className="block p-4 rounded-2xl bg-gradient-to-r from-[#FF3B30] to-[#E52015] text-white shadow-md active:scale-[0.99] transition-transform"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-full bg-white/20 border border-white/25 flex items-center justify-center shrink-0">
              <PhoneCall className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-xs font-extrabold uppercase tracking-wider text-white/90">
                Call Us
              </p>
              <h3 className="text-lg font-black tracking-tight text-white">
                {COMPANY_INFO.primaryPhone}
              </h3>
              <p className="text-[11px] text-white/80 font-medium">
                (Primary) · 24x7 Emergency Line
              </p>
            </div>
          </div>
        </a>

        {/* 2. Green WhatsApp Card */}
        <a
          href={`https://wa.me/${COMPANY_INFO.whatsappPhoneRaw.replace('+', '')}?text=Hello%20SI%20Assistance,%20I%20would%20like%20to%20inquire%20about%20your%20services.`}
          target="_blank"
          rel="noopener noreferrer"
          className="block p-4 rounded-2xl bg-gradient-to-r from-[#00A859] to-[#028A4B] text-white shadow-md active:scale-[0.99] transition-transform"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-full bg-white/20 border border-white/25 flex items-center justify-center shrink-0">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-xs font-extrabold uppercase tracking-wider text-white/90">
                WhatsApp
              </p>
              <h3 className="text-lg font-black tracking-tight text-white font-mono">
                {COMPANY_INFO.whatsappPhone}
              </h3>
              <p className="text-[11px] text-white/80 font-medium">
                (Alternate) · Instant Chat & GPS Location
              </p>
            </div>
          </div>
        </a>

        {/* 3. Address Card */}
        <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0048A7] flex items-center justify-center shrink-0 mt-0.5">
            <MapPin className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] uppercase tracking-wider font-extrabold text-slate-400">
              Our Address
            </p>
            <p className="text-xs font-bold text-slate-900 mt-0.5 leading-snug">
              {COMPANY_INFO.address.full}
            </p>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                COMPANY_INFO.address.full
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-[#0048A7] hover:underline"
            >
              <span>Open in Google Maps</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* 4. Email Card */}
        <a
          href={`mailto:${COMPANY_INFO.email}`}
          className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm flex items-center gap-3.5 hover:border-blue-200 transition-colors"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0048A7] flex items-center justify-center shrink-0">
            <Mail className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] uppercase tracking-wider font-extrabold text-slate-400">
              Email
            </p>
            <p className="text-xs font-bold text-slate-900 truncate mt-0.5">
              {COMPANY_INFO.email}
            </p>
          </div>
        </a>

        {/* 5. Website Card */}
        <a
          href={`https://${COMPANY_INFO.website}`}
          target="_blank"
          rel="noopener noreferrer"
          className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm flex items-center gap-3.5 hover:border-blue-200 transition-colors"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0048A7] flex items-center justify-center shrink-0">
            <Globe className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] uppercase tracking-wider font-extrabold text-slate-400">
              Website
            </p>
            <p className="text-xs font-bold text-[#0048A7] truncate mt-0.5">
              {COMPANY_INFO.website}
            </p>
          </div>
          <ExternalLink className="w-4 h-4 text-slate-400" />
        </a>

        {/* Quick Message Form */}
        <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm mt-4">
          <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider mb-2">
            Send Quick Inquiry
          </h4>
          {submitted ? (
            <div className="p-3 bg-emerald-50 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Thank you! Our support team will call you shortly.</span>
            </div>
          ) : (
            <form onSubmit={handleInquirySubmit} className="space-y-2.5">
              <input
                type="text"
                placeholder="Your Name"
                required
                value={inquiryName}
                onChange={(e) => setInquiryName(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#0048A7]"
              />
              <input
                type="tel"
                placeholder="Your Mobile Number"
                required
                value={inquiryPhone}
                onChange={(e) => setInquiryPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#0048A7]"
              />
              <textarea
                placeholder="Your Message / Requirements"
                rows={2}
                value={inquiryMessage}
                onChange={(e) => setInquiryMessage(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#0048A7]"
              />
              <button
                type="submit"
                className="w-full py-2.5 bg-[#0048A7] hover:bg-blue-800 text-white font-bold text-xs rounded-xl shadow-sm flex items-center justify-center gap-1.5 active:scale-95 transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send Message</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
