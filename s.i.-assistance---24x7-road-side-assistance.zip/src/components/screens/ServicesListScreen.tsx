import React from 'react';
import { ChevronRight, PhoneCall } from 'lucide-react';
import { SERVICES, COMPANY_INFO } from '../../data/mockData';
import { ScreenType } from '../../types';

interface ServicesListScreenProps {
  onSelectService: (serviceId: string) => void;
  onNavigate: (screen: ScreenType) => void;
}

export const ServicesListScreen: React.FC<ServicesListScreenProps> = ({
  onSelectService,
  onNavigate,
}) => {
  return (
    <div className="pb-24 bg-[#F5F7FA] min-h-screen text-slate-900 select-none">
      <div className="p-4 space-y-3">
        {SERVICES.map((service) => (
          <div
            key={service.id}
            onClick={() => {
              onSelectService(service.id);
              onNavigate('service_details');
            }}
            className="flex items-center p-3 bg-white rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.04)] border border-slate-100 hover:border-blue-200 cursor-pointer active:scale-[0.99] transition-all group"
          >
            {/* Thumbnail Image */}
            <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0 bg-slate-100 relative shadow-sm mr-3.5">
              <img
                src={service.image}
                alt={service.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0 pr-2">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight group-hover:text-[#0048A7] transition-colors">
                {service.title}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5 line-clamp-1 font-medium">
                {service.shortDesc}
              </p>
              <div className="mt-2 flex flex-wrap gap-1">
                {service.tags.slice(0, 2).map((tag, i) => (
                  <span
                    key={i}
                    className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Chevron */}
            <div className="text-slate-400 group-hover:text-[#0048A7] transition-colors shrink-0">
              <ChevronRight className="w-5 h-5" />
            </div>
          </div>
        ))}
      </div>

      {/* Instant Help Footer Card */}
      <div className="p-4 pt-0">
        <div className="p-4 bg-gradient-to-r from-blue-50 to-sky-50 border border-blue-200 rounded-2xl flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-[#0048A7]">Need Custom Assistance?</p>
            <p className="text-[11px] text-slate-600">Speak directly to our 24x7 control room</p>
          </div>
          <a
            href={`tel:${COMPANY_INFO.primaryPhoneRaw}`}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#FF4E00] text-white text-xs font-bold rounded-xl shadow-sm active:scale-95 transition-transform"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Call Now</span>
          </a>
        </div>
      </div>
    </div>
  );
};
