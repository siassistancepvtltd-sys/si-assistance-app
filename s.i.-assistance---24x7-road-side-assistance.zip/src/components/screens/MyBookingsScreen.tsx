import React, { useState } from 'react';
import {
  Car,
  Phone,
  MapPin,
  Calendar,
  ChevronRight,
  PlusCircle,
  Truck,
  CreditCard,
  Clock,
} from 'lucide-react';
import { Booking, ScreenType } from '../../types';

interface MyBookingsScreenProps {
  bookings: Booking[];
  onSelectBooking: (booking: Booking) => void;
  onNavigate: (screen: ScreenType) => void;
}

export const MyBookingsScreen: React.FC<MyBookingsScreenProps> = ({
  bookings,
  onSelectBooking,
  onNavigate,
}) => {
  const [filterTab, setFilterTab] = useState<'Current' | 'History'>('Current');

  // Filter current vs history
  const currentBookings = bookings.filter((b) => b.status !== 'Completed');
  const historyBookings = bookings.filter((b) => b.status === 'Completed');

  const displayedBookings =
    filterTab === 'Current' ? currentBookings : historyBookings;

  return (
    <div className="pb-24 bg-[#F5F7FA] min-h-screen text-slate-900 select-none">
      {/* Segmented Control Tabs: Current | History */}
      <div className="p-4 pb-2">
        <div className="flex p-1 bg-slate-200/80 rounded-xl">
          <button
            onClick={() => setFilterTab('Current')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              filterTab === 'Current'
                ? 'bg-[#0048A7] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Current ({currentBookings.length})
          </button>
          <button
            onClick={() => setFilterTab('History')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              filterTab === 'History'
                ? 'bg-[#0048A7] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            History ({historyBookings.length})
          </button>
        </div>
      </div>

      {/* Bookings List */}
      <div className="p-4 pt-2 space-y-4">
        {displayedBookings.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-2xl border border-slate-100 shadow-sm mt-4">
            <Truck className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-sm font-bold text-slate-800">
              No {filterTab.toLowerCase()} bookings found
            </h4>
            <p className="text-xs text-slate-500 mt-1 mb-4">
              Need immediate emergency towing or roadside help?
            </p>
            <button
              onClick={() => onNavigate('booking_form')}
              className="px-4 py-2 bg-[#0048A7] text-white text-xs font-bold rounded-xl shadow-sm"
            >
              Book Roadside Service
            </button>
          </div>
        ) : (
          displayedBookings.map((booking) => (
            <div
              key={booking.id}
              className="bg-white rounded-2xl p-4 shadow-[0_2px_12px_rgba(0,0,0,0.05)] border border-slate-100 space-y-3.5"
            >
              {/* Card Header: Booking ID + Status Badge */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                    Booking ID
                  </span>
                  <span className="text-sm font-extrabold text-slate-900 font-mono tracking-tight">
                    {booking.id}
                  </span>
                </div>
                <span
                  className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${
                    booking.status === 'Completed'
                      ? 'bg-slate-100 text-slate-700'
                      : booking.status === 'On the Way'
                      ? 'bg-amber-100 text-amber-800 animate-pulse'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {booking.status}
                </span>
              </div>

              {/* Service & Details */}
              <div className="space-y-2 text-xs">
                {/* Service Type */}
                <div className="flex items-center gap-2.5 font-bold text-slate-900">
                  <div className="w-6 h-6 rounded-lg bg-blue-50 text-[#0048A7] flex items-center justify-center shrink-0">
                    <Car className="w-3.5 h-3.5" />
                  </div>
                  <span>{booking.serviceType}</span>
                </div>

                {/* Vehicle No */}
                <div className="flex items-center gap-2.5 text-slate-700">
                  <div className="w-6 h-6 rounded-lg bg-slate-100 text-slate-500 flex items-center justify-center shrink-0">
                    <CreditCard className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="text-slate-400 font-medium mr-1.5">Vehicle No:</span>
                    <span className="font-bold font-mono uppercase text-slate-800">
                      {booking.vehicleNumber}
                    </span>
                  </div>
                </div>

                {/* Pickup Location */}
                <div className="flex items-center gap-2.5 text-slate-700">
                  <div className="w-6 h-6 rounded-lg bg-red-50 text-red-500 flex items-center justify-center shrink-0">
                    <MapPin className="w-3.5 h-3.5" />
                  </div>
                  <div className="truncate">
                    <span className="text-slate-400 font-medium mr-1.5">Pickup:</span>
                    <span className="font-semibold text-slate-800">
                      {booking.pickupLocation}
                    </span>
                  </div>
                </div>

                {/* Booked On */}
                <div className="flex items-center gap-2.5 text-slate-700">
                  <div className="w-6 h-6 rounded-lg bg-slate-100 text-slate-500 flex items-center justify-center shrink-0">
                    <Clock className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="text-slate-400 font-medium mr-1.5">Booked On:</span>
                    <span className="font-medium text-slate-600">
                      {booking.bookedOn}
                    </span>
                  </div>
                </div>
              </div>

              {/* Track Status Button */}
              <button
                onClick={() => {
                  onSelectBooking(booking);
                  onNavigate('booking_status');
                }}
                className="w-full h-11 rounded-xl bg-[#0048A7] hover:bg-[#003c8c] text-white text-xs font-bold shadow-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
              >
                <span>Track Status</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          ))
        )}

        {/* Quick New Booking Button */}
        <button
          onClick={() => onNavigate('booking_form')}
          className="w-full py-3 border-2 border-dashed border-slate-300 hover:border-[#0048A7] rounded-2xl flex items-center justify-center gap-2 text-xs font-bold text-slate-600 hover:text-[#0048A7] transition-colors"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Book Another Vehicle / Service</span>
        </button>
      </div>
    </div>
  );
};
