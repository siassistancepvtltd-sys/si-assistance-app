import React from 'react';
import { ChevronLeft, Menu, Bell, Shield, PhoneCall } from 'lucide-react';
import { ScreenType } from '../types';
import { COMPANY_INFO } from '../data/mockData';

interface AppHeaderProps {
  currentScreen: ScreenType;
  title?: string;
  onBack?: () => void;
  onOpenDrawer?: () => void;
  onOpenNotifications?: () => void;
  showStatusBar?: boolean;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  currentScreen,
  title,
  onBack,
  onOpenDrawer,
  onOpenNotifications,
  showStatusBar = true,
}) => {
  const isHome = currentScreen === 'home';
  const isMore = currentScreen === 'more';
  const showBack = !isHome && !isMore && currentScreen !== 'splash';

  return (
    <header className="sticky top-0 z-30 bg-[#0048A7] text-white select-none shadow-md">
      {/* iOS Status Bar Simulation */}
      {showStatusBar && (
        <div className="flex justify-between items-center px-6 pt-2 pb-1 text-xs font-semibold tracking-tight text-white/90">
          <span>9:41</span>
          <div className="flex items-center gap-1.5 text-[11px]">
            {/* Cellular */}
            <svg className="w-4 h-3 fill-current" viewBox="0 0 16 12">
              <rect x="0" y="9" width="2.5" height="3" rx="0.5" />
              <rect x="4" y="6" width="2.5" height="6" rx="0.5" />
              <rect x="8" y="3" width="2.5" height="9" rx="0.5" />
              <rect x="12" y="0" width="2.5" height="12" rx="0.5" />
            </svg>
            {/* WiFi */}
            <svg className="w-3.5 h-3 fill-current" viewBox="0 0 16 12">
              <path d="M8 2.5a10.9 10.9 0 017.3 2.8.8.8 0 01-.1 1.2l-1.2 1a.8.8 0 01-1.1-.1A8 8 0 008 5.6a8 8 0 00-4.9 1.8.8.8 0 01-1.1.1l-1.2-1a.8.8 0 01-.1-1.2A10.9 10.9 0 018 2.5zm0 4.2a6.3 6.3 0 014.1 1.5.8.8 0 010 1.2l-1.1 1a.8.8 0 01-1.1 0 3.8 3.8 0 00-3.8 0 .8.8 0 01-1.1 0l-1.1-1a.8.8 0 010-1.2 6.3 6.3 0 014.1-1.5zM8 9.8a1.8 1.8 0 110 3.6 1.8 1.8 0 010-3.6z" />
            </svg>
            {/* Battery */}
            <div className="w-5 h-2.5 border border-white/90 rounded-sm p-0.5 flex items-center relative">
              <div className="bg-white h-full w-[85%] rounded-[1px]" />
              <div className="w-0.5 h-1 bg-white/90 absolute -right-1 top-0.5 rounded-r-[1px]" />
            </div>
          </div>
        </div>
      )}

      {/* Main App Bar Header */}
      <div className="flex items-center justify-between px-4 py-3 min-h-[52px]">
        {/* Left Slot */}
        <div className="flex items-center min-w-[44px]">
          {showBack ? (
            <button
              onClick={onBack}
              aria-label="Go back"
              className="p-1 -ml-1 text-white hover:bg-white/10 active:bg-white/20 rounded-full transition-colors flex items-center justify-center min-h-[44px] min-w-[44px]"
            >
              <ChevronLeft className="w-6 h-6 stroke-[2.5]" />
            </button>
          ) : (
            <button
              onClick={onOpenDrawer}
              aria-label="Open menu"
              className="p-1 -ml-1 text-white hover:bg-white/10 active:bg-white/20 rounded-lg transition-colors flex items-center justify-center min-h-[44px] min-w-[44px]"
            >
              <Menu className="w-6 h-6" />
            </button>
          )}
        </div>

        {/* Center Title Slot */}
        <div className="flex-1 text-center px-2">
          {title ? (
            <h1 className="text-base font-bold text-white tracking-tight truncate">
              {title}
            </h1>
          ) : (
            <div className="flex flex-col items-center">
              <div className="flex items-center gap-1.5">
                <span className="text-base font-extrabold tracking-tight text-white uppercase">
                  {COMPANY_INFO.name}
                </span>
              </div>
              <span className="text-[10px] tracking-wider text-blue-100 font-semibold uppercase">
                {COMPANY_INFO.subheading}
              </span>
            </div>
          )}
        </div>

        {/* Right Action Slot */}
        <div className="flex items-center justify-end min-w-[44px]">
          {isHome ? (
            <button
              onClick={onOpenNotifications}
              aria-label="Notifications"
              className="relative p-1 text-white hover:bg-white/10 active:bg-white/20 rounded-full transition-colors flex items-center justify-center min-h-[44px] min-w-[44px]"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-amber-400 rounded-full ring-2 ring-[#0048A7]" />
            </button>
          ) : (
            <a
              href={`tel:${COMPANY_INFO.primaryPhoneRaw}`}
              aria-label="Call emergency assistance"
              className="p-1 text-white hover:bg-white/10 active:bg-white/20 rounded-full transition-colors flex items-center justify-center min-h-[44px] min-w-[44px]"
            >
              <PhoneCall className="w-5 h-5 text-amber-300" />
            </a>
          )}
        </div>
      </div>
    </header>
  );
};
