/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AppHeader } from './components/AppHeader';
import { BottomNavBar } from './components/BottomNavBar';
import { DrawerMenu } from './components/DrawerMenu';
import { SplashScreen } from './components/screens/SplashScreen';
import { HomeScreen } from './components/screens/HomeScreen';
import { ServicesListScreen } from './components/screens/ServicesListScreen';
import { ServiceDetailsScreen } from './components/screens/ServiceDetailsScreen';
import { BookingFormScreen } from './components/screens/BookingFormScreen';
import { SelectLocationScreen } from './components/screens/SelectLocationScreen';
import { BookingConfirmationScreen } from './components/screens/BookingConfirmationScreen';
import { MyBookingsScreen } from './components/screens/MyBookingsScreen';
import { BookingStatusTrackingScreen } from './components/screens/BookingStatusTrackingScreen';
import { ContactUsScreen } from './components/screens/ContactUsScreen';
import { AboutUsScreen } from './components/screens/AboutUsScreen';
import { MoreSettingsScreen } from './components/screens/MoreSettingsScreen';
import { ShowcaseGallery } from './components/ShowcaseGallery';
import { INITIAL_BOOKINGS, COMPANY_INFO } from './data/mockData';
import { Booking, BottomTabType, ScreenType, VehicleCategory } from './types';
import {
  Smartphone,
  Maximize2,
  Grid,
  Bell,
  X,
  PhoneCall,
  MessageCircle,
  Truck,
  RotateCcw,
} from 'lucide-react';

export default function App() {
  // Navigation & Screen State
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('home');
  const [screenHistory, setScreenHistory] = useState<ScreenType[]>(['home']);
  const [activeTab, setActiveTab] = useState<BottomTabType>('home');
  const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
  const [notificationOpen, setNotificationOpen] = useState<boolean>(false);

  // View Mode: 'simulator' (iPhone frame), 'responsive' (full width), 'showcase' (12-screen poster)
  const [viewMode, setViewMode] = useState<'simulator' | 'responsive' | 'showcase'>('simulator');

  // Business Data State
  const [bookings, setBookings] = useState<Booking[]>(() => {
    try {
      const stored = localStorage.getItem('si_assistance_bookings');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // Fallback
    }
    return INITIAL_BOOKINGS;
  });

  const [activeBookingId, setActiveBookingId] = useState<string>('SI-2025-00123');
  const [selectedServiceId, setSelectedServiceId] = useState<string>('towing-vehicle-recovery');
  const [selectedVehicleCategory, setSelectedVehicleCategory] = useState<VehicleCategory>('Car');
  const [currentPickupLocation, setCurrentPickupLocation] = useState<string>(
    'Tidhakpur, Kanpur, Uttar Pradesh'
  );

  // Sync bookings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('si_assistance_bookings', JSON.stringify(bookings));
    } catch {
      // Ignore
    }
  }, [bookings]);

  // Navigate function with history tracking
  const navigateTo = (screen: ScreenType) => {
    setScreenHistory((prev) => [...prev, screen]);
    setCurrentScreen(screen);

    // Sync bottom tab based on screen
    if (screen === 'home') setActiveTab('home');
    else if (screen === 'my_bookings' || screen === 'booking_status') setActiveTab('my_bookings');
    else if (screen === 'contact_us') setActiveTab('contact');
    else if (screen === 'more') setActiveTab('more');
  };

  // Back button handler
  const handleBack = () => {
    if (screenHistory.length > 1) {
      const newHistory = [...screenHistory];
      newHistory.pop(); // Remove current
      const prevScreen = newHistory[newHistory.length - 1];
      setScreenHistory(newHistory);
      setCurrentScreen(prevScreen);

      if (prevScreen === 'home') setActiveTab('home');
      else if (prevScreen === 'my_bookings' || prevScreen === 'booking_status') setActiveTab('my_bookings');
      else if (prevScreen === 'contact_us') setActiveTab('contact');
      else if (prevScreen === 'more') setActiveTab('more');
    } else {
      navigateTo('home');
    }
  };

  // Tab change handler
  const handleTabChange = (tab: BottomTabType) => {
    setActiveTab(tab);
    switch (tab) {
      case 'home':
        navigateTo('home');
        break;
      case 'my_bookings':
        navigateTo('my_bookings');
        break;
      case 'contact':
        navigateTo('contact_us');
        break;
      case 'more':
        navigateTo('more');
        break;
    }
  };

  // New Booking Submission
  const handleAddBooking = (newBooking: Booking) => {
    setBookings((prev) => [newBooking, ...prev]);
    setActiveBookingId(newBooking.id);
  };

  // Status Progression Update
  const handleUpdateBookingStatus = (bookingId: string, nextStatus: Booking['status']) => {
    setBookings((prev) =>
      prev.map((b) => {
        if (b.id !== bookingId) return b;

        const updatedTimeline = b.timeline.map((item) => {
          if (nextStatus === 'Confirmed' && item.step === 'Confirmed') {
            return { ...item, completed: true, active: false, time: 'Just now' };
          }
          if (nextStatus === 'Assigned' && (item.step === 'Confirmed' || item.step === 'Assigned')) {
            return { ...item, completed: true, active: false, time: item.step === 'Assigned' ? 'Just now' : item.time };
          }
          if (nextStatus === 'On the Way' && item.step !== 'Completed') {
            return { ...item, completed: true, active: item.step === 'On the Way', time: item.step === 'On the Way' ? 'En route' : item.time };
          }
          if (nextStatus === 'Completed') {
            return { ...item, completed: true, active: false, time: 'Completed' };
          }
          return item;
        });

        return {
          ...b,
          status: nextStatus,
          timeline: updatedTimeline,
        };
      })
    );
  };

  const selectedBooking =
    bookings.find((b) => b.id === activeBookingId) || bookings[0] || null;

  // Determine App Title for Header
  const getHeaderTitle = (): string | undefined => {
    switch (currentScreen) {
      case 'home':
        return undefined; // uses brand logo
      case 'services_list':
        return 'Our Services';
      case 'service_details':
        return 'Towing & Vehicle Recovery';
      case 'booking_form':
        return 'Booking Form';
      case 'select_location':
        return 'Select Location';
      case 'booking_confirmation':
        return 'Booking Confirmation';
      case 'my_bookings':
        return 'My Bookings';
      case 'booking_status':
        return 'Booking Status';
      case 'contact_us':
        return 'Contact Us';
      case 'about_us':
        return 'About Us';
      case 'more':
        return 'More';
      case 'faqs':
        return 'FAQs';
      case 'terms':
        return 'Terms & Conditions';
      case 'privacy':
        return 'Privacy Policy';
      default:
        return undefined;
    }
  };

  // Active bookings count for bottom nav badge
  const activeBookingsCount = bookings.filter((b) => b.status !== 'Completed').length;

  // Show bottom nav on top-level tabs
  const shouldShowBottomNav =
    currentScreen !== 'splash' &&
    currentScreen !== 'select_location' &&
    currentScreen !== 'booking_confirmation';

  return (
    <div className="min-h-screen bg-[#061226] text-slate-900 font-sans antialiased selection:bg-[#0048A7] selection:text-white">
      {/* Top Desktop Controls Bar */}
      <div className="bg-[#040C1A] text-white border-b border-slate-800/80 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs z-50">
        {/* Brand identity badge */}
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-md bg-[#0048A7] flex items-center justify-center">
            <Truck className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div>
            <span className="font-extrabold tracking-tight text-white uppercase">
              {COMPANY_INFO.name}
            </span>
            <span className="text-slate-400 font-mono text-[10px] ml-2 hidden sm:inline">
              24x7 Road Side Assistance
            </span>
          </div>
        </div>

        {/* View Mode Switcher buttons */}
        <div className="flex items-center bg-slate-900 p-0.5 rounded-lg border border-slate-800">
          <button
            onClick={() => setViewMode('simulator')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition-all ${
              viewMode === 'simulator'
                ? 'bg-[#0048A7] text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Mobile App Simulator</span>
            <span className="sm:hidden">App</span>
          </button>

          <button
            onClick={() => setViewMode('responsive')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition-all ${
              viewMode === 'responsive'
                ? 'bg-[#0048A7] text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Expanded View</span>
            <span className="sm:hidden">Full</span>
          </button>

          <button
            onClick={() => setViewMode('showcase')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition-all ${
              viewMode === 'showcase'
                ? 'bg-[#0048A7] text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">12-Screen Showcase</span>
            <span className="sm:hidden">Showcase</span>
          </button>
        </div>

        {/* Quick Emergency Hotlines */}
        <div className="flex items-center gap-2">
          <a
            href={`tel:${COMPANY_INFO.primaryPhoneRaw}`}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-red-600/90 hover:bg-red-600 text-white font-bold text-[11px] transition-colors"
          >
            <PhoneCall className="w-3 h-3" />
            <span>+91 7800045524</span>
          </a>
          <a
            href={`https://wa.me/${COMPANY_INFO.whatsappPhoneRaw.replace('+', '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#00A859] hover:bg-emerald-600 text-white font-bold text-[11px] transition-colors hidden md:inline-flex"
          >
            <MessageCircle className="w-3 h-3" />
            <span>WhatsApp</span>
          </a>
        </div>
      </div>

      {/* Main Content Area */}
      {viewMode === 'showcase' ? (
        <ShowcaseGallery
          onSelectScreenToSimulate={(screen) => {
            navigateTo(screen);
            setViewMode('simulator');
          }}
        />
      ) : (
        <div className="flex justify-center items-start min-h-[calc(100vh-42px)] p-0 sm:py-6 sm:px-4">
          {/* Mobile Container or Responsive Frame */}
          <div
            className={`w-full bg-white relative overflow-hidden transition-all duration-300 ${
              viewMode === 'simulator'
                ? 'max-w-[412px] sm:rounded-[44px] sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7),0_0_0_12px_#1E293B,0_0_0_14px_#334155] sm:min-h-[860px] sm:my-2'
                : 'max-w-2xl sm:rounded-3xl shadow-2xl min-h-[800px]'
            }`}
          >
            {/* iPhone Dynamic Island / Speaker notch simulation in simulator mode */}
            {viewMode === 'simulator' && (
              <div className="hidden sm:block absolute top-2.5 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full z-40 pointer-events-none shadow-sm flex items-center justify-end pr-2.5">
                <div className="w-2.5 h-2.5 rounded-full bg-[#111827] border border-slate-700/60" />
              </div>
            )}

            {/* App Header (except splash screen) */}
            {currentScreen !== 'splash' && (
              <AppHeader
                currentScreen={currentScreen}
                title={getHeaderTitle()}
                onBack={handleBack}
                onOpenDrawer={() => setDrawerOpen(true)}
                onOpenNotifications={() => setNotificationOpen(true)}
                showStatusBar={viewMode === 'simulator'}
              />
            )}

            {/* Drawer Menu */}
            <DrawerMenu
              isOpen={drawerOpen}
              onClose={() => setDrawerOpen(false)}
              onNavigate={(screen) => navigateTo(screen)}
            />

            {/* Notifications Modal */}
            {notificationOpen && (
              <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-start justify-center p-4 pt-16">
                <div className="w-full max-w-sm bg-white rounded-2xl p-4 shadow-2xl animate-in slide-in-from-top-6">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <Bell className="w-4 h-4 text-[#0048A7]" />
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                        Dispatch Notifications
                      </h4>
                    </div>
                    <button
                      onClick={() => setNotificationOpen(false)}
                      className="p-1 rounded-full text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="mt-3 space-y-2.5 text-xs">
                    <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-100">
                      <p className="font-bold text-slate-900">
                        Kanpur Roadside Hotline Live
                      </p>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        Emergency tow trucks and tyre assistance vehicles are stationed
                        at Naubasta, Barra, and GT Road bypasses.
                      </p>
                      <span className="text-[10px] text-slate-400 font-mono mt-1 block">
                        Updated 5 mins ago
                      </span>
                    </div>

                    <div className="p-3 bg-emerald-50/80 rounded-xl border border-emerald-100">
                      <p className="font-bold text-slate-900">
                        WhatsApp Booking Active
                      </p>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        Share live GPS coordinates with our pilot team at +91 9369551292.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Active Screen View */}
            <main className="w-full min-h-[500px]">
              {currentScreen === 'splash' && (
                <SplashScreen onEnterApp={() => navigateTo('home')} />
              )}

              {currentScreen === 'home' && (
                <HomeScreen
                  onNavigate={navigateTo}
                  onSelectService={(id) => setSelectedServiceId(id)}
                  activeBooking={selectedBooking}
                />
              )}

              {currentScreen === 'services_list' && (
                <ServicesListScreen
                  onSelectService={(id) => setSelectedServiceId(id)}
                  onNavigate={navigateTo}
                />
              )}

              {currentScreen === 'service_details' && (
                <ServiceDetailsScreen
                  serviceId={selectedServiceId}
                  onNavigate={navigateTo}
                  onPreselectVehicle={(cat) => setSelectedVehicleCategory(cat)}
                />
              )}

              {currentScreen === 'booking_form' && (
                <BookingFormScreen
                  onNavigate={navigateTo}
                  onSubmitBooking={handleAddBooking}
                  currentPickupLocation={currentPickupLocation}
                  onOpenLocationPicker={() => navigateTo('select_location')}
                  preselectedVehicle={selectedVehicleCategory}
                  preselectedService={
                    selectedServiceId === 'towing-vehicle-recovery'
                      ? 'Car Towing'
                      : selectedServiceId === 'car-carrier-transport'
                      ? 'Car Carrier Transport'
                      : 'Roadside Assistance'
                  }
                />
              )}

              {currentScreen === 'select_location' && (
                <SelectLocationScreen
                  initialLocation={currentPickupLocation}
                  onSelectLocation={(loc) => setCurrentPickupLocation(loc)}
                  onBack={handleBack}
                />
              )}

              {currentScreen === 'booking_confirmation' && (
                <BookingConfirmationScreen
                  booking={selectedBooking}
                  onNavigate={navigateTo}
                />
              )}

              {currentScreen === 'my_bookings' && (
                <MyBookingsScreen
                  bookings={bookings}
                  onSelectBooking={(b) => setActiveBookingId(b.id)}
                  onNavigate={navigateTo}
                />
              )}

              {currentScreen === 'booking_status' && (
                <BookingStatusTrackingScreen
                  booking={selectedBooking}
                  onUpdateBookingStatus={handleUpdateBookingStatus}
                  onNavigate={navigateTo}
                />
              )}

              {currentScreen === 'contact_us' && <ContactUsScreen />}

              {currentScreen === 'about_us' && (
                <AboutUsScreen onNavigate={navigateTo} />
              )}

              {currentScreen === 'more' && (
                <MoreSettingsScreen onNavigate={navigateTo} />
              )}
            </main>

            {/* Bottom Navigation Bar */}
            {shouldShowBottomNav && (
              <BottomNavBar
                activeTab={activeTab}
                onTabChange={handleTabChange}
                bookingCount={activeBookingsCount}
              />
            )}

            {/* iPhone Home Indicator bar in simulator mode */}
            {viewMode === 'simulator' && (
              <div className="hidden sm:block absolute bottom-1.5 left-1/2 -translate-x-1/2 w-32 h-1 bg-slate-900/30 rounded-full z-50 pointer-events-none" />
            )}
          </div>
        </div>
      )}
    </div>
  );
}
