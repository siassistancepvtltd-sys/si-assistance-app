export type ScreenType =
  | 'splash'
  | 'home'
  | 'services_list'
  | 'service_details'
  | 'booking_form'
  | 'select_location'
  | 'booking_confirmation'
  | 'my_bookings'
  | 'booking_status'
  | 'contact_us'
  | 'about_us'
  | 'more'
  | 'faqs'
  | 'terms'
  | 'privacy';

export type BottomTabType = 'home' | 'my_bookings' | 'contact' | 'more';

export type VehicleCategory = 'Car' | 'Bike' | 'SUV' | 'Commercial';

export type BookingStatusStep =
  | 'Request Received'
  | 'Confirmed'
  | 'Assigned'
  | 'On the Way'
  | 'Completed';

export interface TimelineEvent {
  step: BookingStatusStep;
  time: string;
  completed: boolean;
  active?: boolean;
  notes?: string;
}

export interface Booking {
  id: string; // e.g., 'SI-2025-00123'
  serviceType: string;
  vehicleCategory: VehicleCategory;
  name: string;
  mobile: string;
  vehicleNumber: string;
  pickupLocation: string;
  destination?: string;
  problem: string;
  status: 'Received' | 'Confirmed' | 'Assigned' | 'On the Way' | 'Completed';
  bookedOn: string;
  driverName?: string;
  driverPhone?: string;
  driverVehicle?: string;
  estimatedArrival?: string;
  timeline: TimelineEvent[];
}

export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  tags: string[];
  image: string;
  features: string[];
  icon: string;
}
