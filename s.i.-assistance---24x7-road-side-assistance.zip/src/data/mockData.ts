import { Booking, ServiceItem } from '../types';

export const COMPANY_INFO = {
  name: 'S.I.Assistance',
  fullName: 'S.I.Assistance Pvt Ltd',
  subheading: '24x7 ROAD SIDE ASSISTANCE',
  taglineHindi: 'आपकी गाड़ी, हमारी जिम्मेदारी',
  primaryPhone: '+91 7800045524',
  primaryPhoneRaw: '+917800045524',
  whatsappPhone: '+91 9369551292',
  whatsappPhoneRaw: '+919369551292',
  email: 's.i.assistance.pvt.ltd@gmail.com',
  website: 'www.siassistance24x7.in',
  address: {
    line1: 'Shop No. 3, 449-A, Dwiwedi Nagar',
    area: 'Tidhakpur, Naubasta',
    city: 'Kanpur',
    state: 'Uttar Pradesh',
    pincode: '208021',
    full: 'Shop No. 3, 449-A, Dwiwedi Nagar, Tidhakpur, Naubasta, Kanpur, Uttar Pradesh 208021'
  },
  stats: {
    support: '24x7 Support',
    team: 'Experienced Team',
    network: 'Wide Network',
    experienceYears: '10+ Years',
    recoveredVehicles: '25,000+'
  }
};

export const SERVICES: ServiceItem[] = [
  {
    id: 'towing-vehicle-recovery',
    title: 'Towing & Vehicle Recovery',
    shortDesc: 'Car, Bike, SUV, Commercial',
    tags: ['Flatbed', 'Underlift', 'Accident Recovery', 'Long Distance', 'Local Towing'],
    image: '/src/assets/images/hero_flatbed_towing_1793264395416.jpg',
    features: [
      'Flatbed Towing',
      'Underlift Towing',
      'Accident Recovery',
      'Long Distance Transport',
      'Local Towing'
    ],
    icon: 'tow-truck'
  },
  {
    id: 'roadside-assistance',
    title: 'Roadside Assistance',
    shortDesc: 'Battery, Tyre, Fuel, Lockout',
    tags: ['Battery Jumpstart', 'Puncture Repair', 'Fuel Delivery', 'Lockout Assist'],
    image: '/src/assets/images/service_roadside_mechanic_1793264396807.jpg',
    features: [
      'Jumpstart & Battery Replacement',
      'Flat Tyre Change / Air Fill',
      'Emergency Emergency Fuel Delivery (Petrol/Diesel)',
      'Key Lockout & Duplicate Entry Support',
      'On-Spot Minor Diagnosis'
    ],
    icon: 'wrench'
  },
  {
    id: 'car-carrier-transport',
    title: 'Car Carrier & Transport',
    shortDesc: 'City to City / All India',
    tags: ['Inter-City', 'All India Transport', 'Covered Carrier', 'Open Carrier'],
    image: '/src/assets/images/service_car_carrier_truck_1793264396784.jpg',
    features: [
      'Door to Door Vehicle Relocation',
      'All India Interstate Transit Permits',
      'GPS Live Shipment Tracking',
      'Full Transit Insurance Coverage',
      'Single & Multi-Car Carrier Fleets'
    ],
    icon: 'truck'
  },
  {
    id: 'accident-recovery',
    title: 'Accident Recovery',
    shortDesc: 'Crane / Hydra Assistance',
    tags: ['Hydra Crane', 'Winch Pull', 'Off-Road Recovery', 'Ditch Extraction'],
    image: '/src/assets/images/service_accident_recovery_crane_1793264398331.jpg',
    features: [
      'Heavy Duty Hydra Crane Service',
      'Ditch & Rollover Vehicle Extraction',
      'Police & Insurance Protocol Assistance',
      'Safe Damage-Free Winching',
      'Specialized Commercial Recovery Team'
    ],
    icon: 'crane'
  },
  {
    id: 'minor-repair',
    title: 'Minor Repair',
    shortDesc: 'Electrical / Brake / Clutch',
    tags: ['Brake Fluid', 'Clutch Wire', 'Alternator', 'Fuse Replacement'],
    image: '/src/assets/images/service_minor_repair_engine_1793264398257.jpg',
    features: [
      'Electrical System & Fuse Fix',
      'Brake Jam & Wire Adjustment',
      'Clutch Cable Replacement',
      'Coolant Leak & Overheating Fix',
      'Mobile Mechanic On-Site Support'
    ],
    icon: 'tool'
  }
];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'SI-2025-00123',
    serviceType: 'Car Towing',
    vehicleCategory: 'Car',
    name: 'Suresh Verma',
    mobile: '+91 98765 43210',
    vehicleNumber: 'UP78AB1234',
    pickupLocation: 'Tidhakpur, Kanpur',
    destination: 'Authorized Service Center, Naubasta, Kanpur',
    problem: 'Engine breakdown on highway, vehicle stalled and unable to crank.',
    status: 'On the Way',
    bookedOn: '10 Apr 2025, 09:45 AM',
    driverName: 'Rajesh Kumar (Pilot)',
    driverPhone: '+91 7800045524',
    driverVehicle: 'Hydraulic Flatbed Tow Truck (UP78-T-4412)',
    estimatedArrival: '12 mins (3.4 km away)',
    timeline: [
      {
        step: 'Request Received',
        time: '10 Apr 2025, 09:45 AM',
        completed: true,
        notes: 'Emergency booking registered in dispatch system.'
      },
      {
        step: 'Confirmed',
        time: '10 Apr 2025, 09:50 AM',
        completed: true,
        notes: 'Support operator verified pickup coordinates & vehicle model.'
      },
      {
        step: 'Assigned',
        time: '10 Apr 2025, 10:15 AM',
        completed: true,
        notes: 'Driver Rajesh Kumar assigned with Flatbed Unit UP78-T-4412.'
      },
      {
        step: 'On the Way',
        time: '10 Apr 2025, 10:40 AM',
        completed: true,
        active: true,
        notes: 'Driver dispatched and en route via Naubasta Bypass.'
      },
      {
        step: 'Completed',
        time: 'Pending arrival',
        completed: false,
        notes: 'Waiting for roadside pickup and delivery completion.'
      }
    ]
  }
];

export const COMMON_PROBLEMS = [
  'Engine Breakdown / Stalled',
  'Flat Tyre / Puncture',
  'Dead Battery / Jumpstart Needed',
  'Accident Damage / Needs Towing',
  'Keys Locked Inside Car',
  'Out of Fuel (Petrol/Diesel)',
  'Brake Failure / Pedal Soft',
  'Overheating Engine / Steam',
  'Clutch Wire Broken'
];

export const POPULAR_LOCATIONS = [
  { name: 'Tidhakpur, Naubasta, Kanpur', lat: 26.4184, lng: 80.3347 },
  { name: 'Kanpur Central Railway Station', lat: 26.4539, lng: 80.3512 },
  { name: 'GT Road, Kalyanpur, Kanpur', lat: 26.4952, lng: 80.2592 },
  { name: 'Govind Nagar, Kanpur', lat: 26.4468, lng: 80.3015 },
  { name: 'Barra Bypass, Kanpur', lat: 26.4255, lng: 80.2988 },
  { name: 'Civil Lines, Kanpur', lat: 26.4716, lng: 80.3475 },
  { name: 'Lucknow-Kanpur Highway (Unnao)', lat: 26.5410, lng: 80.4900 }
];

export const FAQS = [
  {
    q: 'How fast can S.I.Assistance reach my stranded location?',
    a: 'In Kanpur urban zones and highway bypasses, our nearest mobile pilot typically arrives within 15 to 30 minutes. Across Uttar Pradesh and inter-state corridors, our extensive response network dispatches the closest active flatbed or mechanic.'
  },
  {
    q: 'What information do I need to book roadside assistance?',
    a: 'Simply provide your Name, Mobile Number, Vehicle Registration Number (e.g., UP78AB1234), current pickup location or GPS pin, and describe your issue (towing, jumpstart, puncture, lockout, etc.).'
  },
  {
    q: 'Can I book directly via WhatsApp or phone call?',
    a: 'Yes! You can call our 24x7 emergency hotline at +91 7800045524 immediately, or send your GPS location and vehicle photo on WhatsApp to +91 9369551292.'
  },
  {
    q: 'Do you provide flatbed towing for luxury cars and low-clearance sedans?',
    a: 'Absolutely. We operate full-hydraulic tilt flatbeds with soft-strap tie-downs specifically engineered to prevent underbody scraping or bumper damage on high-end luxury sedans, sports cars, and SUVs.'
  },
  {
    q: 'What types of vehicles do you recover?',
    a: 'We service two-wheelers (motorcycles & scooters), hatchbacks, sedans, SUVs, luxury vehicles, and commercial light & heavy vehicles including cranes and carriers.'
  }
];
